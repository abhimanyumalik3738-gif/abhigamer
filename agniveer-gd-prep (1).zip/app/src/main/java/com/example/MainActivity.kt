package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.DirectionsRun
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ArmyTopBar
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.ExamSimulationScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MockTestsScreen
import com.example.ui.screens.PhysicalGuideScreen
import com.example.ui.screens.PracticeBankScreen
import com.example.ui.screens.ResultScreen
import com.example.ui.screens.ReviewSolutionsScreen
import com.example.ui.theme.ArmyGold
import com.example.ui.theme.ArmyGreenDark
import com.example.ui.theme.ArmyGreenPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ExamViewModel
import com.example.ui.viewmodel.ScreenState

class MainActivity : ComponentActivity() {

    private val examViewModel: ExamViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp(viewModel = examViewModel)
            }
        }
    }
}

data class NavItem(
    val screen: ScreenState,
    val title: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val testTag: String
)

@Composable
fun MainApp(viewModel: ExamViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Handle system back navigation
    BackHandler(enabled = currentScreen != ScreenState.HOME && currentScreen != ScreenState.EXAM_SIMULATION) {
        viewModel.handleBackPress()
    }

    val navItems = listOf(
        NavItem(ScreenState.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
        NavItem(ScreenState.MOCK_TESTS, "Tests & PYQ", Icons.Filled.Assignment, Icons.Outlined.Assignment, "nav_tests"),
        NavItem(ScreenState.PRACTICE_BANK, "Practice", Icons.Filled.MenuBook, Icons.Outlined.MenuBook, "nav_practice"),
        NavItem(ScreenState.PHYSICAL_GUIDE, "Physical", Icons.Filled.DirectionsRun, Icons.Outlined.DirectionsRun, "nav_physical"),
        NavItem(ScreenState.ANALYTICS, "Analytics", Icons.Filled.Analytics, Icons.Outlined.Analytics, "nav_analytics")
    )

    val isFullScreenMode = currentScreen == ScreenState.EXAM_SIMULATION ||
            currentScreen == ScreenState.EXAM_RESULT ||
            currentScreen == ScreenState.REVIEW_SOLUTIONS

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (!isFullScreenMode) {
                ArmyTopBar(
                    title = when (currentScreen) {
                        ScreenState.HOME -> "Agniveer GD CEE"
                        ScreenState.MOCK_TESTS -> "Mock Tests & PYQs"
                        ScreenState.PRACTICE_BANK -> "Subject Practice Bank"
                        ScreenState.PHYSICAL_GUIDE -> "Physical Standards (PET/PMT)"
                        ScreenState.ANALYTICS -> "Candidate Performance"
                        else -> "Agniveer GD"
                    },
                    subtitle = when (currentScreen) {
                        ScreenState.HOME -> "Indian Army Online Exam Preparation"
                        ScreenState.MOCK_TESTS -> "50 Qs • 60 Mins • Real CEE Simulation"
                        ScreenState.PRACTICE_BANK -> "GK • Science • Maths • Reasoning"
                        ScreenState.PHYSICAL_GUIDE -> "1.6 KM Run & Beam Marks Calculator"
                        ScreenState.ANALYTICS -> "Mistake Notebook & Saved Questions"
                        else -> null
                    }
                )
            }
        },
        bottomBar = {
            if (!isFullScreenMode) {
                NavigationBar(
                    containerColor = ArmyGreenDark,
                    tonalElevation = 8.dp,
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    navItems.forEach { item ->
                        val selected = currentScreen == item.screen
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.navigateTo(item.screen) },
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title,
                                    tint = if (selected) ArmyGold else Color.White.copy(alpha = 0.7f)
                                )
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 10.sp
                                    ),
                                    color = if (selected) ArmyGold else Color.White.copy(alpha = 0.7f)
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = ArmyGreenPrimary.copy(alpha = 0.8f)
                            ),
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                ScreenState.HOME -> HomeScreen(viewModel = viewModel)
                ScreenState.MOCK_TESTS -> MockTestsScreen(viewModel = viewModel)
                ScreenState.PRACTICE_BANK -> PracticeBankScreen(viewModel = viewModel)
                ScreenState.PHYSICAL_GUIDE -> PhysicalGuideScreen(viewModel = viewModel)
                ScreenState.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                ScreenState.EXAM_SIMULATION -> ExamSimulationScreen(viewModel = viewModel)
                ScreenState.EXAM_RESULT -> ResultScreen(viewModel = viewModel)
                ScreenState.REVIEW_SOLUTIONS -> ReviewSolutionsScreen(viewModel = viewModel)
            }
        }
    }
}
