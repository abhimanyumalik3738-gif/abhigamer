package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamPaper
import com.example.data.model.PaperType
import com.example.ui.theme.ArmyGold
import com.example.ui.theme.ArmyGreenDark
import com.example.ui.theme.ArmyGreenPrimary
import com.example.ui.theme.ArmyMaroon
import com.example.ui.viewmodel.ExamViewModel
import com.example.ui.viewmodel.ScreenState

enum class FilterCategory(val label: String) {
    ALL("All Exams"),
    PREVIOUS_PAPERS("Previous Papers (PYQs)"),
    FULL_MOCK("Full CEE Mocks"),
    SECTIONAL("Sectional Drills")
}

@Composable
fun MockTestsScreen(
    viewModel: ExamViewModel,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(FilterCategory.ALL) }
    val allPapers = viewModel.getAllPapers()
    val testAttempts by viewModel.testAttempts.collectAsState()

    val filteredPapers = remember(selectedFilter, allPapers) {
        when (selectedFilter) {
            FilterCategory.ALL -> allPapers
            FilterCategory.PREVIOUS_PAPERS -> allPapers.filter { it.type == PaperType.PREVIOUS_YEAR_PAPER }
            FilterCategory.FULL_MOCK -> allPapers.filter { it.type == PaperType.FULL_MOCK || it.type == PaperType.DAILY_MOCK }
            FilterCategory.SECTIONAL -> allPapers.filter { it.type == PaperType.SECTIONAL }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Filter Chips Row
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(FilterCategory.values()) { category ->
                FilterChip(
                    selected = selectedFilter == category,
                    onClick = { selectedFilter = category },
                    label = { Text(category.label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ArmyGreenPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // List of Tests
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredPapers) { paper ->
                val bestAttempt = testAttempts.filter { it.paperId == paper.id }.maxByOrNull { it.score }

                ExamPaperCard(
                    paper = paper,
                    bestScore = bestAttempt?.score,
                    maxScore = paper.totalMarks,
                    isPassed = bestAttempt?.isPassed,
                    onStartExam = { viewModel.startExam(paper) }
                )
            }
        }
    }
}

@Composable
fun ExamPaperCard(
    paper: ExamPaper,
    bestScore: Float?,
    maxScore: Float,
    isPassed: Boolean?,
    onStartExam: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("paper_card_${paper.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Type badge and Target Year
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = when (paper.type) {
                        PaperType.PREVIOUS_YEAR_PAPER -> ArmyMaroon.copy(alpha = 0.15f)
                        PaperType.DAILY_MOCK -> ArmyGold.copy(alpha = 0.2f)
                        else -> ArmyGreenPrimary.copy(alpha = 0.15f)
                    }
                ) {
                    Text(
                        text = when (paper.type) {
                            PaperType.PREVIOUS_YEAR_PAPER -> "ORIGINAL PREVIOUS PAPER"
                            PaperType.DAILY_MOCK -> "TODAY'S LIVE MOCK"
                            PaperType.FULL_MOCK -> "ALL INDIA CEE MOCK"
                            PaperType.SECTIONAL -> "SPEED DRILL"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
                        color = when (paper.type) {
                            PaperType.PREVIOUS_YEAR_PAPER -> ArmyMaroon
                            PaperType.DAILY_MOCK -> Color(0xFFB78103)
                            else -> ArmyGreenPrimary
                        },
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = paper.targetYear,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Title
            Text(
                text = paper.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = paper.titleHi,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Specs Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Assignment,
                        contentDescription = null,
                        tint = ArmyGreenPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${paper.totalQuestions} Questions",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = ArmyGreenPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${paper.durationMinutes} Mins",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "${paper.totalMarks.toInt()} Marks (-0.50)",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Previous attempt badge if taken
            if (bestScore != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPassed == true) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (isPassed == true) Color(0xFF2E7D32) else Color(0xFFC62828),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Best Score: ${String.format("%.1f", bestScore)} / ${maxScore.toInt()} • ${if (isPassed == true) "QUALIFIED" else "NEEDS IMPROVEMENT"}",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isPassed == true) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Button
            Button(
                onClick = onStartExam,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("start_test_${paper.id}"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ArmyGreenPrimary,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "START TIMED EXAM",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}
