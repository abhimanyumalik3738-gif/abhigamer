package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BookmarkEntity
import com.example.data.local.MistakeEntity
import com.example.data.local.TestAttemptEntity
import com.example.data.model.AgniveerPhysicalStandards
import com.example.data.model.ExamPaper
import com.example.data.model.PaperType
import com.example.data.model.Question
import com.example.data.model.Subject
import com.example.data.model.TestResult
import com.example.data.repository.ExamRepository
import com.example.data.repository.MockData
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScreenState {
    HOME,
    MOCK_TESTS,
    PRACTICE_BANK,
    PHYSICAL_GUIDE,
    ANALYTICS,
    EXAM_SIMULATION,
    EXAM_RESULT,
    REVIEW_SOLUTIONS
}

data class ExamUiState(
    val currentPaper: ExamPaper? = null,
    val currentQuestionIndex: Int = 0,
    val userAnswers: Map<String, Int> = emptyMap(),
    val markedForReview: Set<String> = emptySet(),
    val visitedQuestions: Set<String> = emptySet(),
    val remainingSeconds: Int = 0,
    val isTimerRunning: Boolean = false,
    val isHindi: Boolean = false,
    val isPaletteOpen: Boolean = false,
    val isSubmitDialogVisible: Boolean = false,
    val latestResult: TestResult? = null
)

data class PracticeUiState(
    val selectedSubject: Subject = Subject.GK,
    val currentIndex: Int = 0,
    val selectedOption: Int? = null,
    val isAnswerChecked: Boolean = false,
    val isBookmarked: Boolean = false,
    val isHindi: Boolean = false
)

class ExamViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ExamRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = ExamRepository(db.appDao())
    }

    // Navigation screen
    private val _currentScreen = MutableStateFlow(ScreenState.HOME)
    val currentScreen: StateFlow<ScreenState> = _currentScreen.asStateFlow()

    // Screen backstack for Android BackHandler navigation
    private val screenBackStack = mutableListOf(ScreenState.HOME)

    // Exam state
    private val _examState = MutableStateFlow(ExamUiState())
    val examState: StateFlow<ExamUiState> = _examState.asStateFlow()

    private var timerJob: Job? = null

    // Practice Bank state
    private val _practiceState = MutableStateFlow(PracticeUiState())
    val practiceState: StateFlow<PracticeUiState> = _practiceState.asStateFlow()

    // Physical Calculator State
    val runMinutes = MutableStateFlow("5")
    val runSeconds = MutableStateFlow("20")
    val pullUpsCount = MutableStateFlow("10")
    val physicalScore = MutableStateFlow(Pair(100, "EXCELLENT! 100/100 Physical Marks (Group 1 + 10 Pull-ups)"))

    // Room Flows
    val testAttempts: StateFlow<List<TestAttemptEntity>> = repository.getAllAttempts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookmarks: StateFlow<List<BookmarkEntity>> = repository.getAllBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mistakes: StateFlow<List<MistakeEntity>> = repository.getAllMistakes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun navigateTo(screen: ScreenState) {
        if (_currentScreen.value != screen) {
            screenBackStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun handleBackPress(): Boolean {
        if (screenBackStack.size > 1) {
            screenBackStack.removeAt(screenBackStack.lastIndex)
            val previous = screenBackStack.last()
            _currentScreen.value = previous
            return true
        }
        return false
    }

    fun toggleExamLanguage() {
        _examState.value = _examState.value.copy(isHindi = !_examState.value.isHindi)
    }

    fun togglePracticeLanguage() {
        _practiceState.value = _practiceState.value.copy(isHindi = !_practiceState.value.isHindi)
    }

    fun startExam(paper: ExamPaper) {
        timerJob?.cancel()
        val durationSeconds = paper.durationMinutes * 60
        val firstQ = paper.questions.firstOrNull()?.id
        val visited = if (firstQ != null) setOf(firstQ) else emptySet()

        _examState.value = ExamUiState(
            currentPaper = paper,
            currentQuestionIndex = 0,
            userAnswers = emptyMap(),
            markedForReview = emptySet(),
            visitedQuestions = visited,
            remainingSeconds = durationSeconds,
            isTimerRunning = true,
            isHindi = false,
            isPaletteOpen = false,
            isSubmitDialogVisible = false,
            latestResult = null
        )

        timerJob = viewModelScope.launch {
            while (_examState.value.remainingSeconds > 0 && _examState.value.isTimerRunning) {
                delay(1000)
                val newSeconds = _examState.value.remainingSeconds - 1
                _examState.value = _examState.value.copy(remainingSeconds = newSeconds)
                if (newSeconds <= 0) {
                    submitExam()
                    break
                }
            }
        }

        navigateTo(ScreenState.EXAM_SIMULATION)
    }

    fun selectOption(questionId: String, optionIndex: Int) {
        val updated = _examState.value.userAnswers.toMutableMap()
        updated[questionId] = optionIndex
        _examState.value = _examState.value.copy(userAnswers = updated)
    }

    fun clearOption(questionId: String) {
        val updated = _examState.value.userAnswers.toMutableMap()
        updated.remove(questionId)
        _examState.value = _examState.value.copy(userAnswers = updated)
    }

    fun toggleMarkForReview(questionId: String) {
        val current = _examState.value.markedForReview.toMutableSet()
        if (current.contains(questionId)) {
            current.remove(questionId)
        } else {
            current.add(questionId)
        }
        _examState.value = _examState.value.copy(markedForReview = current)
    }

    fun jumpToQuestion(index: Int) {
        val paper = _examState.value.currentPaper ?: return
        if (index in 0 until paper.questions.size) {
            val qId = paper.questions[index].id
            val updatedVisited = _examState.value.visitedQuestions + qId
            _examState.value = _examState.value.copy(
                currentQuestionIndex = index,
                visitedQuestions = updatedVisited,
                isPaletteOpen = false
            )
        }
    }

    fun nextQuestion() {
        val paper = _examState.value.currentPaper ?: return
        val nextIdx = _examState.value.currentQuestionIndex + 1
        if (nextIdx < paper.questions.size) {
            jumpToQuestion(nextIdx)
        }
    }

    fun previousQuestion() {
        val prevIdx = _examState.value.currentQuestionIndex - 1
        if (prevIdx >= 0) {
            jumpToQuestion(prevIdx)
        }
    }

    fun setPaletteOpen(isOpen: Boolean) {
        _examState.value = _examState.value.copy(isPaletteOpen = isOpen)
    }

    fun setSubmitDialogVisible(isVisible: Boolean) {
        _examState.value = _examState.value.copy(isSubmitDialogVisible = isVisible)
    }

    fun submitExam() {
        timerJob?.cancel()
        val paper = _examState.value.currentPaper ?: return
        val totalSeconds = paper.durationMinutes * 60
        val timeSpent = totalSeconds - _examState.value.remainingSeconds

        viewModelScope.launch {
            val result = repository.saveTestResult(
                paper = paper,
                userAnswers = _examState.value.userAnswers,
                timeSpentSeconds = maxOf(1, timeSpent)
            )
            _examState.value = _examState.value.copy(
                latestResult = result,
                isTimerRunning = false,
                isSubmitDialogVisible = false
            )
            navigateTo(ScreenState.EXAM_RESULT)
        }
    }

    // Practice Bank methods
    fun selectPracticeSubject(subject: Subject) {
        _practiceState.value = _practiceState.value.copy(
            selectedSubject = subject,
            currentIndex = 0,
            selectedOption = null,
            isAnswerChecked = false
        )
    }

    fun selectPracticeOption(index: Int) {
        _practiceState.value = _practiceState.value.copy(selectedOption = index)
    }

    fun checkPracticeAnswer() {
        val state = _practiceState.value
        val questions = repository.getQuestionsBySubject(state.selectedSubject)
        val q = questions.getOrNull(state.currentIndex) ?: return

        _practiceState.value = state.copy(isAnswerChecked = true)

        if (state.selectedOption != null && state.selectedOption != q.correctOptionIndex) {
            viewModelScope.launch {
                val db = AppDatabase.getDatabase(getApplication())
                db.appDao().insertOrUpdateMistake(
                    MistakeEntity(
                        questionId = q.id,
                        subject = q.subject.name,
                        lastAttemptTimestamp = System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun nextPracticeQuestion() {
        val state = _practiceState.value
        val questions = repository.getQuestionsBySubject(state.selectedSubject)
        val nextIdx = (state.currentIndex + 1) % questions.size
        _practiceState.value = state.copy(
            currentIndex = nextIdx,
            selectedOption = null,
            isAnswerChecked = false
        )
    }

    fun prevPracticeQuestion() {
        val state = _practiceState.value
        val questions = repository.getQuestionsBySubject(state.selectedSubject)
        val prevIdx = if (state.currentIndex - 1 < 0) questions.size - 1 else state.currentIndex - 1
        _practiceState.value = state.copy(
            currentIndex = prevIdx,
            selectedOption = null,
            isAnswerChecked = false
        )
    }

    fun toggleBookmark(questionId: String, subject: Subject) {
        viewModelScope.launch {
            val isCurrent = bookmarks.value.any { it.questionId == questionId }
            repository.toggleBookmark(questionId, subject, isCurrent)
        }
    }

    // Physical Calculator
    fun updatePhysicalScore() {
        val mins = runMinutes.value.toIntOrNull() ?: 5
        val secs = runSeconds.value.toIntOrNull() ?: 30
        val totalSecs = (mins * 60) + secs
        val pulls = pullUpsCount.value.toIntOrNull() ?: 10
        physicalScore.value = AgniveerPhysicalStandards.calculatePhysicalScore(totalSecs, pulls)
    }

    fun getAllPapers(): List<ExamPaper> = repository.getAllExamPapers()

    fun getQuestionsForSubject(subject: Subject): List<Question> = repository.getQuestionsBySubject(subject)

    fun getQuestionById(qId: String): Question? = repository.getQuestionById(qId)
}
