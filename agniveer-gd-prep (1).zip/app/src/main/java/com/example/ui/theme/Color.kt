package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Army Agniveer Palette
val ArmyGreenDark = Color(0xFF142417)
val ArmyGreenPrimary = Color(0xFF23442A)
val ArmyGreenMedium = Color(0xFF335C3B)
val ArmyGreenLight = Color(0xFF4C7D56)
val ArmyGreenContainer = Color(0xFFD3E8D6)
val ArmyOnGreenContainer = Color(0xFF0A2B12)

// Brass / Gold Accents (Regimental Brass)
val ArmyGold = Color(0xFFD4AF37)
val ArmyGoldLight = Color(0xFFF7D974)
val ArmyGoldDark = Color(0xFF9E7E1B)

// Maroon / Gallantry Red
val ArmyMaroon = Color(0xFF8B1E1E)
val ArmyMaroonContainer = Color(0xFFFFDAD6)
val ArmyOnMaroonContainer = Color(0xFF410002)

// Neutrals
val CamoBackground = Color(0xFFF7F9F6)
val CamoSurface = Color(0xFFFFFFFF)
val CamoSurfaceVariant = Color(0xFFE8ECE7)
val CamoOutline = Color(0xFF717D72)
val CamoOnSurface = Color(0xFF191D1A)
val CamoOnSurfaceVariant = Color(0xFF404942)

// Dark Theme Colors
val DarkBackground = Color(0xFF101612)
val DarkSurface = Color(0xFF161E18)
val DarkSurfaceVariant = Color(0xFF222C24)
val DarkPrimary = Color(0xFF7BC98D)
val DarkSecondary = Color(0xFFE2C46C)
val DarkOnSurface = Color(0xFFE1E5DF)
val DarkOnSurfaceVariant = Color(0xFFC1C9C0)

// Quiz status colors
val ColorAnswered = Color(0xFF2E7D32)
val ColorWrong = Color(0xFFC62828)
val ColorReview = Color(0xFF7B1FA2)
val ColorUnanswered = Color(0xFFD32F2F)
val ColorNotVisited = Color(0xFF757575)
