package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ArmyTopBar
import com.example.ui.components.QuestionOptionItem
import com.example.ui.components.SubjectBadge
import com.example.ui.theme.ArmyGold
import com.example.ui.theme.ArmyGreenDark
import com.example.ui.theme.ArmyGreenPrimary
import com.example.ui.theme.ColorAnswered
import com.example.ui.theme.ColorUnanswered
import com.example.ui.theme.ColorWrong
import com.example.ui.viewmodel.ExamViewModel
import com.example.ui.viewmodel.ScreenState

enum class ReviewFilter(val label: String) {
    ALL("All Questions"),
    INCORRECT("Incorrect Only"),
    CORRECT("Correct Only"),
    UNANSWERED("Unanswered")
}

@Composable
fun ReviewSolutionsScreen(
    viewModel: ExamViewModel,
    modifier: Modifier = Modifier
) {
    val examState by viewModel.examState.collectAsState()
    val paper = examState.currentPaper
    val result = examState.latestResult
    val bookmarks by viewModel.bookmarks.collectAsState()

    BackHandler {
        viewModel.navigateTo(ScreenState.EXAM_RESULT)
    }

    if (paper == null || result == null) {
        Column(modifier = modifier.fillMaxSize()) {
            Text("No test to review.")
        }
        return
    }

    var selectedFilter by remember { mutableStateOf(ReviewFilter.ALL) }

    val userAnswers = result.userAnswers

    val filteredQuestions = remember(selectedFilter, paper.questions, userAnswers) {
        paper.questions.filterIndexed { index, q ->
            val userAns = userAnswers[q.id]
            when (selectedFilter) {
                ReviewFilter.ALL -> true
                ReviewFilter.INCORRECT -> userAns != null && userAns != q.correctOptionIndex
                ReviewFilter.CORRECT -> userAns != null && userAns == q.correctOptionIndex
                ReviewFilter.UNANSWERED -> userAns == null
            }
        }
    }

    Scaffold(
        topBar = {
            ArmyTopBar(
                title = "Solutions & Explanations",
                subtitle = "${paper.title} (${filteredQuestions.size} shown)",
                onBackClick = { viewModel.navigateTo(ScreenState.EXAM_RESULT) }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Filter chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(ReviewFilter.values().toList()) { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ArmyGreenPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Questions list with solutions
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(filteredQuestions) { displayIdx, question ->
                    val userAns = userAnswers[question.id]
                    val isCorrect = userAns != null && userAns == question.correctOptionIndex
                    val isWrong = userAns != null && userAns != question.correctOptionIndex
                    val isBookmarked = bookmarks.any { it.questionId == question.id }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("review_card_${question.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Header: Status, Subject, Bookmark
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    SubjectBadge(subject = question.subject)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = when {
                                            isCorrect -> ColorAnswered.copy(alpha = 0.15f)
                                            isWrong -> ColorWrong.copy(alpha = 0.15f)
                                            else -> ColorUnanswered.copy(alpha = 0.15f)
                                        }
                                    ) {
                                        Text(
                                            text = when {
                                                isCorrect -> "CORRECT (+2.0)"
                                                isWrong -> "WRONG (-0.50)"
                                                else -> "SKIPPED (0.0)"
                                            },
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
                                            color = when {
                                                isCorrect -> ColorAnswered
                                                isWrong -> ColorWrong
                                                else -> ColorUnanswered
                                            },
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { viewModel.toggleBookmark(question.id, question.subject) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                        contentDescription = "Bookmark",
                                        tint = if (isBookmarked) ArmyGold else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Question bilingual text
                            Text(
                                text = question.questionEn,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = question.questionHi,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Options
                            val letters = listOf("A", "B", "C", "D")
                            question.optionsEn.forEachIndexed { optIdx, optText ->
                                val isOptionSelected = userAns == optIdx
                                val isOptionCorrect = question.correctOptionIndex == optIdx

                                QuestionOptionItem(
                                    optionIndex = optIdx,
                                    optionLetter = letters.getOrElse(optIdx) { "?" },
                                    optionText = "$optText (${question.optionsHi.getOrElse(optIdx) { "" }})",
                                    isSelected = isOptionSelected,
                                    isCorrectAnswer = isOptionCorrect,
                                    showEvaluation = true,
                                    onSelect = {}
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Explanation Box
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = ArmyGreenPrimary.copy(alpha = 0.08f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Lightbulb,
                                            contentDescription = null,
                                            tint = ArmyGold,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Explanation / व्याख्या",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = ArmyGreenPrimary
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = question.explanationEn,
                                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = question.explanationHi,
                                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
