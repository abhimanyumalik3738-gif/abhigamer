package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subject
import com.example.ui.components.QuestionOptionItem
import com.example.ui.components.SubjectBadge
import com.example.ui.theme.ArmyGold
import com.example.ui.theme.ArmyGreenDark
import com.example.ui.theme.ArmyGreenPrimary
import com.example.ui.viewmodel.ExamViewModel

@Composable
fun PracticeBankScreen(
    viewModel: ExamViewModel,
    modifier: Modifier = Modifier
) {
    val practiceState by viewModel.practiceState.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()

    val subjects = listOf(Subject.GK, Subject.GS, Subject.MATHS, Subject.REASONING)
    val selectedSubjectIdx = subjects.indexOf(practiceState.selectedSubject).coerceAtLeast(0)

    val questions = viewModel.getQuestionsForSubject(practiceState.selectedSubject)
    val currentIdx = practiceState.currentIndex.coerceIn(0, (questions.size - 1).coerceAtLeast(0))
    val currentQuestion = questions.getOrNull(currentIdx)

    val isBookmarked = currentQuestion != null && bookmarks.any { it.questionId == currentQuestion.id }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Subject Tabs
        TabRow(
            selectedTabIndex = selectedSubjectIdx,
            containerColor = ArmyGreenDark,
            contentColor = ArmyGold
        ) {
            subjects.forEachIndexed { index, subject ->
                Tab(
                    selected = selectedSubjectIdx == index,
                    onClick = { viewModel.selectPracticeSubject(subject) },
                    text = {
                        Text(
                            text = subject.name,
                            fontWeight = if (selectedSubjectIdx == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedSubjectIdx == index) ArmyGold else Color.White.copy(alpha = 0.7f)
                        )
                    }
                )
            }
        }

        if (currentQuestion == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No questions in this category.")
            }
            return
        }

        // Practice Area
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Control Header: Question index, Language Switch, Bookmark
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SubjectBadge(subject = currentQuestion.subject)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (practiceState.isHindi) ArmyGold else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .clickable { viewModel.togglePracticeLanguage() }
                            .testTag("practice_lang_toggle")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = null,
                                tint = if (practiceState.isHindi) ArmyGreenDark else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (practiceState.isHindi) "हिन्दी" else "ENG",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (practiceState.isHindi) ArmyGreenDark else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { viewModel.toggleBookmark(currentQuestion.id, currentQuestion.subject) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Bookmark",
                            tint = if (isBookmarked) ArmyGold else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Question ${currentIdx + 1} of ${questions.size} • ${currentQuestion.topic}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Question Box
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val qPrimary = if (practiceState.isHindi) currentQuestion.questionHi else currentQuestion.questionEn
                    val qSecondary = if (practiceState.isHindi) currentQuestion.questionEn else currentQuestion.questionHi

                    Text(
                        text = qPrimary,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = qSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Options
            val options = if (practiceState.isHindi) currentQuestion.optionsHi else currentQuestion.optionsEn
            val letters = listOf("A", "B", "C", "D")

            options.forEachIndexed { optIdx, optText ->
                QuestionOptionItem(
                    optionIndex = optIdx,
                    optionLetter = letters.getOrElse(optIdx) { "?" },
                    optionText = optText,
                    isSelected = practiceState.selectedOption == optIdx,
                    isCorrectAnswer = if (practiceState.isAnswerChecked) optIdx == currentQuestion.correctOptionIndex else null,
                    showEvaluation = practiceState.isAnswerChecked,
                    onSelect = {
                        if (!practiceState.isAnswerChecked) {
                            viewModel.selectPracticeOption(optIdx)
                        }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Check Answer Button
            if (!practiceState.isAnswerChecked) {
                Button(
                    onClick = { viewModel.checkPracticeAnswer() },
                    enabled = practiceState.selectedOption != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("check_answer_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = ArmyGreenPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("CHECK ANSWER / उत्तर जांचें", fontWeight = FontWeight.Bold)
                }
            }

            // Explanation Section if checked
            AnimatedVisibility(visible = practiceState.isAnswerChecked) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = ArmyGreenPrimary.copy(alpha = 0.08f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = ArmyGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Solution & Key Concept",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = ArmyGreenPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = currentQuestion.explanationEn,
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = currentQuestion.explanationHi,
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Next & Previous buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.prevPracticeQuestion() },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Previous")
                }

                Button(
                    onClick = { viewModel.nextPracticeQuestion() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = ArmyGreenPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Next Question")
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}
