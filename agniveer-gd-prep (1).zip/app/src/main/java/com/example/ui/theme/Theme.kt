package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = ArmyGreenDark,
    primaryContainer = ArmyGreenMedium,
    onPrimaryContainer = Color(0xFFD4E8D7),
    secondary = DarkSecondary,
    onSecondary = Color(0xFF382E00),
    secondaryContainer = ArmyGoldDark,
    onSecondaryContainer = Color(0xFFFFEEB2),
    tertiary = Color(0xFFFFB4AB),
    onTertiary = Color(0xFF690005),
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = CamoOutline
)

private val LightColorScheme = lightColorScheme(
    primary = ArmyGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = ArmyGreenContainer,
    onPrimaryContainer = ArmyOnGreenContainer,
    secondary = ArmyGoldDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFBEBB5),
    onSecondaryContainer = Color(0xFF241A00),
    tertiary = ArmyMaroon,
    onTertiary = Color.White,
    tertiaryContainer = ArmyMaroonContainer,
    onTertiaryContainer = ArmyOnMaroonContainer,
    background = CamoBackground,
    onBackground = CamoOnSurface,
    surface = CamoSurface,
    onSurface = CamoOnSurface,
    surfaceVariant = CamoSurfaceVariant,
    onSurfaceVariant = CamoOnSurfaceVariant,
    outline = CamoOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our curated army theme by default for military atmosphere
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
