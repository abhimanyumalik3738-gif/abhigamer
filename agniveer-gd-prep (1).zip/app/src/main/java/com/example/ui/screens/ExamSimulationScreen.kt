package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Question
import com.example.data.model.Subject
import com.example.ui.components.QuestionOptionItem
import com.example.ui.components.QuestionPaletteItem
import com.example.ui.components.SubjectBadge
import com.example.ui.theme.ArmyGold
import com.example.ui.theme.ArmyGreenDark
import com.example.ui.theme.ArmyGreenPrimary
import com.example.ui.theme.ArmyMaroon
import com.example.ui.theme.ColorAnswered
import com.example.ui.theme.ColorNotVisited
import com.example.ui.theme.ColorReview
import com.example.ui.theme.ColorUnanswered
import com.example.ui.viewmodel.ExamViewModel
import com.example.ui.viewmodel.ScreenState

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExamSimulationScreen(
    viewModel: ExamViewModel,
    modifier: Modifier = Modifier
) {
    val examState by viewModel.examState.collectAsState()
    val paper = examState.currentPaper ?: return
    val questions = paper.questions
    val currentIdx = examState.currentQuestionIndex.coerceIn(0, questions.lastIndex)
    val currentQuestion = questions.getOrNull(currentIdx) ?: return

    // Intercept back button to confirm before quitting live exam
    BackHandler {
        viewModel.setSubmitDialogVisible(true)
    }

    val minutes = examState.remainingSeconds / 60
    val seconds = examState.remainingSeconds % 60
    val isTimeLow = examState.remainingSeconds <= 300 // under 5 mins

    // Section tabs (GK, GS, Maths, Reasoning)
    val activeSubject = currentQuestion.subject
    val subjects = listOf(Subject.GK, Subject.GS, Subject.MATHS, Subject.REASONING)
    val activeTabIdx = subjects.indexOf(activeSubject).coerceAtLeast(0)

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = paper.title,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            maxLines = 1
                        )
                        Text(
                            text = "Question ${currentIdx + 1} of ${questions.size}",
                            style = MaterialTheme.typography.labelSmall,
                            color = ArmyGold
                        )
                    }
                },
                actions = {
                    // Language toggle (EN / हिं)
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (examState.isHindi) ArmyGold else Color.White.copy(alpha = 0.2f),
                        modifier = Modifier
                            .clickable { viewModel.toggleExamLanguage() }
                            .padding(end = 6.dp)
                            .testTag("exam_lang_toggle")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = if (examState.isHindi) ArmyGreenDark else Color.White,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (examState.isHindi) "हिन्दी" else "ENG",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (examState.isHindi) ArmyGreenDark else Color.White
                            )
                        }
                    }

                    // Countdown Timer Pill
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isTimeLow) ArmyMaroon else ArmyGreenPrimary,
                        modifier = Modifier.padding(end = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Timer",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = String.format("%02d:%02d", minutes, seconds),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                    }

                    // Question Palette Toggle Button
                    IconButton(
                        onClick = { viewModel.setPaletteOpen(true) },
                        modifier = Modifier.testTag("open_palette_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.GridView,
                            contentDescription = "Question Palette",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ArmyGreenDark,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            // Exam CBT Navigation Controls
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Secondary action row: Clear Response & Mark for Review
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { viewModel.clearOption(currentQuestion.id) },
                            modifier = Modifier.testTag("clear_response_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Clear",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }

                        val isMarked = examState.markedForReview.contains(currentQuestion.id)
                        FilledTonalButton(
                            onClick = { viewModel.toggleMarkForReview(currentQuestion.id) },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = if (isMarked) ColorReview else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (isMarked) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("mark_review_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Flag,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isMarked) "Marked" else "Mark for Review",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }

                        Button(
                            onClick = { viewModel.setSubmitDialogVisible(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = ArmyMaroon),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("submit_exam_top_btn")
                        ) {
                            Text(
                                text = "Submit",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Primary navigation row: Previous and Save & Next
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.previousQuestion() },
                            enabled = currentIdx > 0,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_prev_question"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Previous")
                        }

                        Button(
                            onClick = {
                                if (currentIdx == questions.lastIndex) {
                                    viewModel.setSubmitDialogVisible(true)
                                } else {
                                    viewModel.nextQuestion()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_next_question"),
                            colors = ButtonDefaults.buttonColors(containerColor = ArmyGreenPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (currentIdx == questions.lastIndex) "Submit Test" else "Save & Next",
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Subject Section Tabs
            ScrollableTabRow(
                selectedTabIndex = activeTabIdx,
                containerColor = ArmyGreenDark.copy(alpha = 0.95f),
                contentColor = Color.White,
                indicator = { tabPositions ->
                    if (activeTabIdx < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[activeTabIdx]),
                            color = ArmyGold,
                            height = 3.dp
                        )
                    }
                },
                edgePadding = 12.dp
            ) {
                subjects.forEachIndexed { index, subject ->
                    val sectionQuestions = questions.filter { it.subject == subject }
                    val answeredCount = sectionQuestions.count { examState.userAnswers.containsKey(it.id) }
                    Tab(
                        selected = activeTabIdx == index,
                        onClick = {
                            val targetFirstIdx = questions.indexOfFirst { it.subject == subject }
                            if (targetFirstIdx >= 0) {
                                viewModel.jumpToQuestion(targetFirstIdx)
                            }
                        },
                        text = {
                            Text(
                                text = "${subject.name} ($answeredCount/${sectionQuestions.size})",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (activeTabIdx == index) FontWeight.Bold else FontWeight.Normal
                                ),
                                color = if (activeTabIdx == index) ArmyGold else Color.White.copy(alpha = 0.7f)
                            )
                        }
                    )
                }
            }

            // Question Details & Options Scrollable Area
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                // Header badge: Subject and Marks
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SubjectBadge(subject = currentQuestion.subject)

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = ArmyGreenPrimary.copy(alpha = 0.1f)
                    ) {
                        Text(
                            text = "+2.0  /  -0.50 Mark",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = ArmyGreenPrimary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Question Text Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Q.${currentIdx + 1}",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = ArmyGreenPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        val qText = if (examState.isHindi) currentQuestion.questionHi else currentQuestion.questionEn
                        Text(
                            text = qText,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                lineHeight = 24.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        // If in English, also show subtle Hindi below (or vice-versa) for clarity
                        val secondaryText = if (examState.isHindi) currentQuestion.questionEn else currentQuestion.questionHi
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = secondaryText,
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Select one answer:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 4 Options
                val options = if (examState.isHindi) currentQuestion.optionsHi else currentQuestion.optionsEn
                val letters = listOf("A", "B", "C", "D")
                val selectedOption = examState.userAnswers[currentQuestion.id]

                options.forEachIndexed { optIdx, optText ->
                    QuestionOptionItem(
                        optionIndex = optIdx,
                        optionLetter = letters.getOrElse(optIdx) { "?" },
                        optionText = optText,
                        isSelected = selectedOption == optIdx,
                        showEvaluation = false,
                        onSelect = { viewModel.selectOption(currentQuestion.id, optIdx) }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }
    }

    // Modal Bottom Sheet: Full 50 Question Palette
    if (examState.isPaletteOpen) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.setPaletteOpen(false) },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Question Palette (${questions.size} Questions)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Legend
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PaletteLegendItem(color = ColorAnswered, label = "Answered")
                    PaletteLegendItem(color = ColorUnanswered, label = "Not Answered")
                    PaletteLegendItem(color = ColorReview, label = "Review")
                    PaletteLegendItem(color = ColorNotVisited, label = "Not Visited")
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Grid of 50 questions
                FlowRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    questions.forEachIndexed { qIndex, q ->
                        val isAnswered = examState.userAnswers.containsKey(q.id)
                        val isMarked = examState.markedForReview.contains(q.id)
                        val isVisited = examState.visitedQuestions.contains(q.id)
                        val isCurrent = qIndex == currentIdx

                        QuestionPaletteItem(
                            questionNumber = qIndex + 1,
                            isAnswered = isAnswered,
                            isMarkedForReview = isMarked,
                            isVisited = isVisited,
                            isCurrent = isCurrent,
                            onClick = { viewModel.jumpToQuestion(qIndex) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Submit Confirmation Dialog
    if (examState.isSubmitDialogVisible) {
        val total = questions.size
        val answered = examState.userAnswers.size
        val marked = examState.markedForReview.size
        val unanswered = total - answered

        AlertDialog(
            onDismissRequest = { viewModel.setSubmitDialogVisible(false) },
            title = {
                Text(
                    text = "Submit CEE Exam?",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Are you sure you want to finish the exam?")
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("• Total Questions: $total")
                    Text("• Answered: $answered", color = ColorAnswered, fontWeight = FontWeight.Bold)
                    Text("• Marked for Review: $marked", color = ColorReview)
                    Text("• Unanswered: $unanswered", color = ColorUnanswered)
                }
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.submitExam() },
                    colors = ButtonDefaults.buttonColors(containerColor = ArmyGreenPrimary),
                    modifier = Modifier.testTag("confirm_submit_btn")
                ) {
                    Text("Yes, Submit Test")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.setSubmitDialogVisible(false) }) {
                    Text("Resume Test")
                }
            }
        )
    }
}

@Composable
fun PaletteLegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
