package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subject
import com.example.ui.theme.ArmyGold
import com.example.ui.theme.ArmyGreenDark
import com.example.ui.theme.ArmyGreenPrimary
import com.example.ui.theme.ArmyMaroon
import com.example.ui.theme.ColorAnswered
import com.example.ui.theme.ColorNotVisited
import com.example.ui.theme.ColorReview
import com.example.ui.theme.ColorUnanswered
import com.example.ui.theme.ColorWrong

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArmyTopBar(
    title: String,
    subtitle: String? = null,
    onBackClick: (() -> Unit)? = null,
    actions: @Composable () -> Unit = {}
) {
    TopAppBar(
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MilitaryTech,
                        contentDescription = "Army Badge",
                        tint = ArmyGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = ArmyGold.copy(alpha = 0.9f)
                    )
                }
            }
        },
        navigationIcon = {
            if (onBackClick != null) {
                IconButton(onClick = onBackClick, modifier = Modifier.testTag("nav_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            }
        },
        actions = { actions() },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = ArmyGreenDark,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White
        )
    )
}

@Composable
fun SubjectBadge(
    subject: Subject,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = ArmyGreenPrimary.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, ArmyGreenPrimary.copy(alpha = 0.3f)),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(ArmyGold)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "${subject.titleEn} (${subject.titleHi})",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = ArmyGreenPrimary
            )
        }
    }
}

@Composable
fun QuestionOptionItem(
    optionIndex: Int,
    optionLetter: String,
    optionText: String,
    isSelected: Boolean,
    isCorrectAnswer: Boolean? = null,
    showEvaluation: Boolean = false,
    onSelect: () -> Unit
) {
    val borderColor by animateColorAsState(
        targetValue = when {
            showEvaluation && isCorrectAnswer == true -> ColorAnswered
            showEvaluation && isSelected && isCorrectAnswer == false -> ColorWrong
            isSelected -> ArmyGreenPrimary
            else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        },
        label = "borderColor"
    )

    val containerColor by animateColorAsState(
        targetValue = when {
            showEvaluation && isCorrectAnswer == true -> ColorAnswered.copy(alpha = 0.12f)
            showEvaluation && isSelected && isCorrectAnswer == false -> ColorWrong.copy(alpha = 0.12f)
            isSelected -> ArmyGreenPrimary.copy(alpha = 0.08f)
            else -> MaterialTheme.colorScheme.surface
        },
        label = "containerColor"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .testTag("option_$optionIndex"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(if (isSelected || (showEvaluation && isCorrectAnswer == true)) 2.dp else 1.dp, borderColor)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            // Letter circle
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            showEvaluation && isCorrectAnswer == true -> ColorAnswered
                            showEvaluation && isSelected && isCorrectAnswer == false -> ColorWrong
                            isSelected -> ArmyGreenPrimary
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = optionLetter,
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    color = if (isSelected || showEvaluation) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = optionText,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                    lineHeight = 22.sp
                ),
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )

            if (showEvaluation && isCorrectAnswer == true) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Correct",
                    tint = ColorAnswered,
                    modifier = Modifier.size(22.dp)
                )
            } else if (showEvaluation && isSelected && isCorrectAnswer == false) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Incorrect",
                    tint = ColorWrong,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
fun QuestionPaletteItem(
    questionNumber: Int,
    isAnswered: Boolean,
    isMarkedForReview: Boolean,
    isVisited: Boolean,
    isCurrent: Boolean,
    onClick: () -> Unit
) {
    val bgColor = when {
        isMarkedForReview -> ColorReview
        isAnswered -> ColorAnswered
        isVisited -> ColorUnanswered
        else -> ColorNotVisited
    }

    Box(
        modifier = Modifier
            .size(42.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .then(
                if (isCurrent) Modifier.background(bgColor) else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "$questionNumber",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White
        )
    }
}
