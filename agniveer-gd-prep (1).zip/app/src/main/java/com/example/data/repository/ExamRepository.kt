package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.BookmarkEntity
import com.example.data.local.MistakeEntity
import com.example.data.local.TestAttemptEntity
import com.example.data.model.ExamPaper
import com.example.data.model.Question
import com.example.data.model.Subject
import com.example.data.model.SubjectScoreSummary
import com.example.data.model.TestResult
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

class ExamRepository(private val appDao: AppDao) {

    fun getAllExamPapers(): List<ExamPaper> = MockData.allExamPapers

    fun getExamPaperById(paperId: String): ExamPaper? {
        return MockData.allExamPapers.find { it.id == paperId }
    }

    fun getAllQuestions(): List<Question> = MockData.standardCee50Questions

    fun getQuestionById(questionId: String): Question? {
        return MockData.standardCee50Questions.find { it.id == questionId }
    }

    fun getQuestionsBySubject(subject: Subject): List<Question> {
        return MockData.standardCee50Questions.filter { it.subject == subject }
    }

    // Attempt storage
    suspend fun saveTestResult(
        paper: ExamPaper,
        userAnswers: Map<String, Int>,
        timeSpentSeconds: Int
    ): TestResult {
        var correctCount = 0
        var wrongCount = 0
        var unansweredCount = 0

        val subjectStats = mutableMapOf<Subject, MutableList<Pair<Boolean?, Float>>>()
        Subject.values().forEach { subjectStats[it] = mutableListOf() }

        paper.questions.forEach { q ->
            val selected = userAnswers[q.id]
            if (selected == null) {
                unansweredCount++
                subjectStats[q.subject]?.add(Pair(null, 0f))
            } else if (selected == q.correctOptionIndex) {
                correctCount++
                subjectStats[q.subject]?.add(Pair(true, paper.markPerCorrect))
            } else {
                wrongCount++
                subjectStats[q.subject]?.add(Pair(false, -paper.negativeMarkPerWrong))
                // Log mistake into database
                appDao.insertOrUpdateMistake(
                    MistakeEntity(
                        questionId = q.id,
                        subject = q.subject.name,
                        lastAttemptTimestamp = System.currentTimeMillis()
                    )
                )
            }
        }

        val rawScore = (correctCount * paper.markPerCorrect) - (wrongCount * paper.negativeMarkPerWrong)
        val score = maxOf(0f, rawScore)
        val isPassed = score >= paper.passingMarks
        val attemptedCount = correctCount + wrongCount
        val accuracy = if (attemptedCount > 0) (correctCount.toFloat() / attemptedCount) * 100f else 0f

        val breakdown = subjectStats.mapValues { (subject, results) ->
            val totalInSubject = results.size
            val att = results.count { it.first != null }
            val cor = results.count { it.first == true }
            val wrg = results.count { it.first == false }
            val subScore = maxOf(0f, results.sumOf { it.second.toDouble() }.toFloat())
            val maxSubScore = totalInSubject * paper.markPerCorrect
            SubjectScoreSummary(
                totalQuestions = totalInSubject,
                attempted = att,
                correct = cor,
                wrong = wrg,
                score = subScore,
                maxScore = maxSubScore
            )
        }

        val json = JSONObject()
        userAnswers.forEach { (k, v) -> json.put(k, v) }

        val entity = TestAttemptEntity(
            paperId = paper.id,
            paperTitle = paper.title,
            timestamp = System.currentTimeMillis(),
            score = score,
            maxScore = paper.totalMarks,
            isPassed = isPassed,
            correctCount = correctCount,
            wrongCount = wrongCount,
            unansweredCount = unansweredCount,
            timeSpentSeconds = timeSpentSeconds,
            userAnswersJson = json.toString()
        )

        val insertedId = appDao.insertTestAttempt(entity)

        return TestResult(
            attemptId = insertedId,
            paperId = paper.id,
            paperTitle = paper.title,
            timestamp = entity.timestamp,
            timeSpentSeconds = timeSpentSeconds,
            score = score,
            maxScore = paper.totalMarks,
            isPassed = isPassed,
            totalQuestions = paper.totalQuestions,
            attemptedCount = attemptedCount,
            correctCount = correctCount,
            wrongCount = wrongCount,
            unansweredCount = unansweredCount,
            accuracyPercentage = accuracy,
            userAnswers = userAnswers,
            subjectBreakdown = breakdown
        )
    }

    fun getAllAttempts(): Flow<List<TestAttemptEntity>> = appDao.getAllTestAttempts()

    suspend fun getBestAttempt(paperId: String): TestAttemptEntity? = appDao.getBestAttemptForPaper(paperId)

    // Bookmarks
    fun getAllBookmarks(): Flow<List<BookmarkEntity>> = appDao.getAllBookmarks()

    suspend fun toggleBookmark(questionId: String, subject: Subject, isCurrentlyBookmarked: Boolean) {
        if (isCurrentlyBookmarked) {
            appDao.deleteBookmark(questionId)
        } else {
            appDao.insertBookmark(BookmarkEntity(questionId = questionId, subject = subject.name))
        }
    }

    fun isBookmarked(questionId: String): Flow<Boolean> = appDao.isQuestionBookmarked(questionId)

    // Mistakes
    fun getAllMistakes(): Flow<List<MistakeEntity>> = appDao.getAllMistakes()

    suspend fun clearMistake(questionId: String) = appDao.deleteMistake(questionId)
}
