package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "test_attempts")
data class TestAttemptEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val paperId: String,
    val paperTitle: String,
    val timestamp: Long,
    val score: Float,
    val maxScore: Float,
    val isPassed: Boolean,
    val correctCount: Int,
    val wrongCount: Int,
    val unansweredCount: Int,
    val timeSpentSeconds: Int,
    val userAnswersJson: String
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey
    val questionId: String,
    val subject: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "mistakes")
data class MistakeEntity(
    @PrimaryKey
    val questionId: String,
    val subject: String,
    val wrongCount: Int = 1,
    val lastAttemptTimestamp: Long = System.currentTimeMillis()
)
