package com.example.data.repository

import com.example.data.model.ExamPaper
import com.example.data.model.PaperType
import com.example.data.model.Question
import com.example.data.model.Subject

object MockData {

    // --- GENERAL KNOWLEDGE (GK) QUESTIONS ---
    val gkQuestions = listOf(
        Question(
            id = "gk_1",
            subject = Subject.GK,
            topic = "Defense & Armed Forces",
            topicHi = "रक्षा एवं सशस्त्र बल",
            questionEn = "Who was the first Chief of Defence Staff (CDS) of India?",
            questionHi = "भारत के प्रथम चीफ ऑफ डिफेंस स्टाफ (CDS) कौन थे?",
            optionsEn = listOf("General Bipin Rawat", "General Manoj Mukund Naravane", "General Anil Chauhan", "Field Marshal Sam Manekshaw"),
            optionsHi = listOf("जनरल बिपिन रावत", "जनरल मनोज मुकुंद नरवणे", "जनरल अनिल चौहान", "फील्ड मार्शल सैम मानेकशॉ"),
            correctOptionIndex = 0,
            explanationEn = "General Bipin Rawat was appointed as India's first Chief of Defence Staff on 1 January 2020.",
            explanationHi = "जनरल बिपिन रावत को 1 जनवरी 2020 को भारत का पहला चीफ ऑफ डिफेंस स्टाफ नियुक्त किया गया था।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gk_2",
            subject = Subject.GK,
            topic = "Defense & Armed Forces",
            topicHi = "रक्षा एवं सशस्त्र बल",
            questionEn = "Where is the Northern Command Headquarters of the Indian Army located?",
            questionHi = "भारतीय सेना की उत्तरी कमान (Northern Command) का मुख्यालय कहाँ स्थित है?",
            optionsEn = listOf("Shimla", "Udhampur", "Chandimandir", "Lucknow"),
            optionsHi = listOf("शिमला", "उधमपुर", "चंडीमंदिर", "लखनऊ"),
            correctOptionIndex = 1,
            explanationEn = "The Northern Command of the Indian Army is headquartered at Udhampur, Jammu and Kashmir.",
            explanationHi = "भारतीय सेना की उत्तरी कमान का मुख्यालय उधमपुर, जम्मू एवं कश्मीर में स्थित है।",
            sourceYear = "Army GD Danapur 2023"
        ),
        Question(
            id = "gk_3",
            subject = Subject.GK,
            topic = "Indian History",
            topicHi = "भारतीय इतिहास",
            questionEn = "In which year did the Kargil War take place?",
            questionHi = "कारगिल युद्ध किस वर्ष लड़ा गया था?",
            optionsEn = listOf("1971", "1999", "1965", "1962"),
            optionsHi = listOf("1971", "1999", "1965", "1962"),
            correctOptionIndex = 1,
            explanationEn = "The Kargil War was fought between India and Pakistan from May to July 1999 in Jammu and Kashmir's Kargil district. India declared victory on 26 July (Kargil Vijay Diwas).",
            explanationHi = "कारगिल युद्ध मई से जुलाई 1999 के बीच भारत और पाकिस्तान के बीच लड़ा गया। 26 जुलाई को भारत ने 'ऑपरेशन विजय' की सफलता के साथ जीत हासिल की।",
            sourceYear = "Agniveer CEE 2023"
        ),
        Question(
            id = "gk_4",
            subject = Subject.GK,
            topic = "Constitution & Polity",
            topicHi = "संविधान एवं राजव्यवस्था",
            questionEn = "Who is the Supreme Commander of the Indian Armed Forces?",
            questionHi = "भारतीय सशस्त्र बलों का सर्वोच्च सेनापति कौन होता है?",
            optionsEn = listOf("Prime Minister", "Chief of Army Staff", "President of India", "Defence Minister"),
            optionsHi = listOf("प्रधानमंत्री", "थल सेनाध्यक्ष", "भारत के राष्ट्रपति", "रक्षा मंत्री"),
            correctOptionIndex = 2,
            explanationEn = "According to Article 53 of the Constitution of India, the Supreme Command of the Defence Forces of the Union is vested in the President of India.",
            explanationHi = "भारतीय संविधान के अनुच्छेद 53 के अनुसार, संघ के सशस्त्र बलों की सर्वोच्च कमान भारत के राष्ट्रपति में निहित होती है।",
            sourceYear = "Army GD 2022"
        ),
        Question(
            id = "gk_5",
            subject = Subject.GK,
            topic = "Defense Honors",
            topicHi = "सैन्य सम्मान",
            questionEn = "Which is the highest military gallantry award in India during wartime?",
            questionHi = "युद्धकाल में भारत का सर्वोच्च सैन्य वीरता पुरस्कार कौन सा है?",
            optionsEn = listOf("Maha Vir Chakra", "Ashoka Chakra", "Param Vir Chakra", "Kirti Chakra"),
            optionsHi = listOf("महावीर चक्र", "अशोक चक्र", "परमवीर चक्र", "कीर्ति चक्र"),
            correctOptionIndex = 2,
            explanationEn = "Param Vir Chakra (PVC) is India's highest wartime gallantry medal. Major Somnath Sharma was its first recipient.",
            explanationHi = "परमवीर चक्र युद्धकाल में सर्वोच्च वीरता पदक है। मेजर सोमनाथ शर्मा इसके प्रथम प्राप्तकर्ता थे।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gk_6",
            subject = Subject.GK,
            topic = "National Emblems & Symbols",
            topicHi = "राष्ट्रीय प्रतीक",
            questionEn = "Who wrote India's National Anthem 'Jana Gana Mana'?",
            questionHi = "भारत के राष्ट्रगान 'जन गण मन' के रचयिता कौन हैं?",
            optionsEn = listOf("Bankim Chandra Chatterjee", "Rabindranath Tagore", "Sarojini Naidu", "Swami Vivekananda"),
            optionsHi = listOf("बंकिम चंद्र चटर्जी", "रवींद्रनाथ टैगोर", "सरोजिनी नायडू", "स्वामी विवेकानंद"),
            correctOptionIndex = 1,
            explanationEn = "Rabindranath Tagore wrote the national anthem 'Jana Gana Mana' in Bengali, officially adopted by the Constituent Assembly on 24 Jan 1950.",
            explanationHi = "रवींद्रनाथ टैगोर ने राष्ट्रगान 'जन गण मन' की रचना की थी, जिसे 24 जनवरी 1950 को संविधान सभा द्वारा अंगीकृत किया गया।",
            sourceYear = "Agniveer GD 2023"
        ),
        Question(
            id = "gk_7",
            subject = Subject.GK,
            topic = "Indian Geography",
            topicHi = "भारतीय भूगोल",
            questionEn = "Which Indian state has the longest mainland coastline?",
            questionHi = "भारत के किस राज्य की मुख्य भूमि तटरेखा सबसे लंबी है?",
            optionsEn = listOf("Maharashtra", "Tamil Nadu", "Gujarat", "Andhra Pradesh"),
            optionsHi = listOf("महाराष्ट्र", "तमिलनाडु", "गुजरात", "आंध्र प्रदेश"),
            correctOptionIndex = 2,
            explanationEn = "Gujarat has the longest coastline among Indian states, stretching approximately 1,600 kilometers.",
            explanationHi = "गुजरात राज्य की तटरेखा सबसे लंबी है, जो लगभग 1,600 किमी तक फैली है।",
            sourceYear = "Army GD 2021"
        ),
        Question(
            id = "gk_8",
            subject = Subject.GK,
            topic = "Defense Academies",
            topicHi = "सैन्य प्रशिक्षण संस्थान",
            questionEn = "Where is the National Defence Academy (NDA) located?",
            questionHi = "राष्ट्रीय रक्षा अकादमी (NDA) कहाँ स्थित है?",
            optionsEn = listOf("Dehradun", "Khadakwasla (Pune)", "Mhow", "Chennai"),
            optionsHi = listOf("देहरादून", "खड़कवासला (पुणे)", "महू", "चेन्नई"),
            correctOptionIndex = 1,
            explanationEn = "The National Defence Academy (NDA) is situated at Khadakwasla near Pune, Maharashtra.",
            explanationHi = "राष्ट्रीय रक्षा अकादमी (NDA) पुणे, महाराष्ट्र के निकट खड़कवासला में स्थित है। देहरादून में IMA (इंडियन मिलिट्री एकेडमी) है।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gk_9",
            subject = Subject.GK,
            topic = "Indian Geography",
            topicHi = "भारतीय भूगोल",
            questionEn = "Which river is popularly known as the 'Sorrow of Bihar'?",
            questionHi = "'बिहार का शोक' किस नदी को कहा जाता है?",
            optionsEn = listOf("Gandak", "Kosi", "Ganga", "Son"),
            optionsHi = listOf("गंडक", "कोसी", "गंगा", "सोन"),
            correctOptionIndex = 1,
            explanationEn = "River Kosi causes massive flooding and frequently changes its course, earning the title 'Sorrow of Bihar'.",
            explanationHi = "कोसी नदी अपने मार्ग परिवर्तन और भयंकर बाढ़ के कारण 'बिहार का शोक' कहलाती है।",
            sourceYear = "Army GD Lucknow 2022"
        ),
        Question(
            id = "gk_10",
            subject = Subject.GK,
            topic = "Defense Scheme",
            topicHi = "अग्निवीर योजना",
            questionEn = "What is the service tenure of an Agniveer in the Indian Armed Forces under the Agnipath scheme?",
            questionHi = "अग्निपथ योजना के तहत भारतीय सेना में एक अग्निवीर की सेवा अवधि कितनी होती है?",
            optionsEn = listOf("3 Years", "4 Years", "5 Years", "7 Years"),
            optionsHi = listOf("3 वर्ष", "4 वर्ष", "5 वर्ष", "7 वर्ष"),
            correctOptionIndex = 1,
            explanationEn = "Candidates enrolled under the Agnipath Scheme serve for a period of 4 years, after which up to 25% are enrolled into regular cadre.",
            explanationHi = "अग्निपथ योजना के अंतर्गत अग्निवीरों की प्रारंभिक सेवा अवधि 4 वर्ष होती है, जिसमें से 25% को स्थायी कैडर में शामिल किया जाता है।",
            sourceYear = "Agniveer CEE 2023"
        ),
        Question(
            id = "gk_11",
            subject = Subject.GK,
            topic = "Freedom Struggle",
            topicHi = "स्वतंत्रता संग्राम",
            questionEn = "Who gave the famous slogan 'Jai Jawan, Jai Kisan'?",
            questionHi = "'जय जवान, जय किसान' का प्रसिद्ध नारा किसने दिया था?",
            optionsEn = listOf("Subhash Chandra Bose", "Lal Bahadur Shastri", "Bhagat Singh", "Mahatma Gandhi"),
            optionsHi = listOf("सुभाष चंद्र बोस", "लाल बहादुर शास्त्री", "भगत सिंह", "महात्मा गांधी"),
            correctOptionIndex = 1,
            explanationEn = "Prime Minister Lal Bahadur Shastri coined 'Jai Jawan, Jai Kisan' during the 1965 Indo-Pak war.",
            explanationHi = "1965 के भारत-पाक युद्ध के समय तत्कालीन प्रधानमंत्री लाल बहादुर शास्त्री ने 'जय जवान, जय किसान' का नारा दिया था।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gk_12",
            subject = Subject.GK,
            topic = "Space & Science",
            topicHi = "अंतरिक्ष एवं अनुसंधान",
            questionEn = "What was the name of India's first artificial satellite launched in 1975?",
            questionHi = "1975 में प्रक्षेपित भारत के पहले कृत्रिम उपग्रह का नाम क्या था?",
            optionsEn = listOf("Bhaskara", "Rohini", "Aryabhata", "Chandrayaan"),
            optionsHi = listOf("भास्कर", "रोहिणी", "आर्यभट्ट", "चंद्रयान"),
            correctOptionIndex = 2,
            explanationEn = "Aryabhata was India's first satellite, launched on 19 April 1975 by the Soviet Union on behalf of ISRO.",
            explanationHi = "भारत का पहला उपग्रह 'आर्यभट्ट' था जिसे 19 अप्रैल 1975 को सोवियत संघ के सहयोग से प्रक्षेपित किया गया था।",
            sourceYear = "Army GD 2022"
        ),
        Question(
            id = "gk_13",
            subject = Subject.GK,
            topic = "World & Solar System",
            topicHi = "सौरमंडल",
            questionEn = "Which planet is known as the 'Red Planet'?",
            questionHi = "सौरमंडल के किस ग्रह को 'लाल ग्रह' कहा जाता है?",
            optionsEn = listOf("Venus", "Mars", "Jupiter", "Saturn"),
            optionsHi = listOf("शुक्र", "मंगल", "बृहस्पति", "शनि"),
            correctOptionIndex = 1,
            explanationEn = "Mars is called the Red Planet due to the high presence of iron oxide (rust) on its surface.",
            explanationHi = "मंगल ग्रह की सतह पर आयरन ऑक्साइड (लौह ऑक्साइड) की अधिकता के कारण यह लाल दिखाई देता है।",
            sourceYear = "Agniveer CEE 2023"
        ),
        Question(
            id = "gk_14",
            subject = Subject.GK,
            topic = "Indian History",
            topicHi = "भारतीय इतिहास",
            questionEn = "The First Battle of Panipat was fought in which year?",
            questionHi = "पानीपत की पहली लड़ाई किस वर्ष लड़ी गई थी?",
            optionsEn = listOf("1526", "1556", "1761", "1576"),
            optionsHi = listOf("1526", "1556", "1761", "1576"),
            correctOptionIndex = 0,
            explanationEn = "The First Battle of Panipat was fought on 21 April 1526 between Babur and Ibrahim Lodi, marking the beginning of the Mughal Empire.",
            explanationHi = "पानीपत की पहली लड़ाई 21 अप्रैल 1526 को बाबर और इब्राहिम लोदी के बीच लड़ी गई थी।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gk_15",
            subject = Subject.GK,
            topic = "Sports & Awards",
            topicHi = "खेल एवं पुरस्कार",
            questionEn = "Dronacharya Award is presented for excellence in which field?",
            questionHi = "द्रोणाचार्य पुरस्कार किस क्षेत्र में उत्कृष्टता के लिए प्रदान किया जाता है?",
            optionsEn = listOf("Best Athlete", "Sports Coaches", "Literary Writing", "Cinema Direction"),
            optionsHi = listOf("सर्वश्रेष्ठ खिलाड़ी", "खेल प्रशिक्षक (कोच)", "साहित्य लेखन", "सिनेमा निर्देशन"),
            correctOptionIndex = 1,
            explanationEn = "Dronacharya Award is awarded by the Ministry of Youth Affairs and Sports to outstanding sports coaches.",
            explanationHi = "द्रोणाचार्य पुरस्कार खेल प्रशिक्षकों (Coaches) को उनके उल्लेखनीय योगदान और मार्गदर्शन के लिए दिया जाता है।",
            sourceYear = "Army GD Danapur 2023"
        )
    )

    // --- GENERAL SCIENCE (GS) QUESTIONS ---
    val gsQuestions = listOf(
        Question(
            id = "gs_1",
            subject = Subject.GS,
            topic = "Chemistry",
            topicHi = "रसायन विज्ञान",
            questionEn = "What is the chemical formula of common salt (table salt)?",
            questionHi = "साधारण नमक का रासायनिक सूत्र क्या है?",
            optionsEn = listOf("NaCl", "KCl", "NaOH", "Na2CO3"),
            optionsHi = listOf("NaCl", "KCl", "NaOH", "Na2CO3"),
            correctOptionIndex = 0,
            explanationEn = "Common salt is Sodium Chloride, chemical formula NaCl.",
            explanationHi = "साधारण नमक का रासायनिक नाम सोडियम क्लोराइड और सूत्र NaCl होता है।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gs_2",
            subject = Subject.GS,
            topic = "Biology - Human Body",
            topicHi = "जीव विज्ञान - मानव शरीर",
            questionEn = "What is the normal human body temperature in Celsius and Fahrenheit?",
            questionHi = "स्वस्थ मानव शरीर का सामान्य तापमान कितना होता है?",
            optionsEn = listOf("37°C / 98.6°F", "35°C / 95.0°F", "39°C / 102.0°F", "32°C / 90.0°F"),
            optionsHi = listOf("37°C / 98.6°F", "35°C / 95.0°F", "39°C / 102.0°F", "32°C / 90.0°F"),
            correctOptionIndex = 0,
            explanationEn = "Normal human body temperature is approximately 37°C or 98.6°F.",
            explanationHi = "स्वस्थ मनुष्य के शरीर का सामान्य तापमान 37° सेल्सियस या 98.6° फारेनहाइट होता है।",
            sourceYear = "Army GD 2023"
        ),
        Question(
            id = "gs_3",
            subject = Subject.GS,
            topic = "Physics - Mechanics",
            topicHi = "भौतिकी - यांत्रिकी",
            questionEn = "What is the SI unit of electric current?",
            questionHi = "विद्युत धारा का SI मात्रक क्या है?",
            optionsEn = listOf("Volt", "Watt", "Ampere", "Ohm"),
            optionsHi = listOf("वोल्ट", "वाट", "एम्पीयर", "ओम"),
            correctOptionIndex = 2,
            explanationEn = "The SI unit of electric current is Ampere (symbol A).",
            explanationHi = "विद्युत धारा (Electric Current) का SI मात्रक एम्पीयर (A) है। वोल्ट विभवांतर का और ओम प्रतिरोध का मात्रक है।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gs_4",
            subject = Subject.GS,
            topic = "Chemistry",
            topicHi = "रसायन विज्ञान",
            questionEn = "Which gas is essential for combustion (burning)?",
            questionHi = "किसी वस्तु के जलने (दहन) के लिए कौन सी गैस आवश्यक होती है?",
            optionsEn = listOf("Nitrogen", "Oxygen", "Carbon Dioxide", "Hydrogen"),
            optionsHi = listOf("नाइट्रोजन", "ऑक्सीजन", "कार्बन डाइऑक्साइड", "हाइड्रोजन"),
            correctOptionIndex = 1,
            explanationEn = "Oxygen supports combustion and is necessary for fire to burn.",
            explanationHi = "दहन के लिए ऑक्सीजन गैस अनिवार्य होती है। नाइट्रोजन और कार्बन डाइऑक्साइड आग बुझाने में मदद करती हैं।",
            sourceYear = "Agniveer CEE 2023"
        ),
        Question(
            id = "gs_5",
            subject = Subject.GS,
            topic = "Physics - Light",
            topicHi = "भौतिकी - प्रकाश",
            questionEn = "What is the speed of light in vacuum?",
            questionHi = "निर्वात में प्रकाश की चाल कितनी होती है?",
            optionsEn = listOf("3 × 10^8 m/s", "3 × 10^6 m/s", "332 m/s", "3 × 10^10 m/s"),
            optionsHi = listOf("3 × 10^8 मी/से", "3 × 10^6 मी/से", "332 मी/से", "3 × 10^10 मी/से"),
            correctOptionIndex = 0,
            explanationEn = "The speed of light in vacuum is approximately 300,000 km/s or 3 × 10^8 meters per second.",
            explanationHi = "निर्वात में प्रकाश की चाल 3 × 10^8 मीटर प्रति सेकंड (3 लाख किमी/से) होती है।",
            sourceYear = "Army GD Danapur 2022"
        ),
        Question(
            id = "gs_6",
            subject = Subject.GS,
            topic = "Biology - Nutrition",
            topicHi = "जीव विज्ञान - पोषण",
            questionEn = "Deficiency of Vitamin C causes which disease?",
            questionHi = "विटामिन सी की कमी से कौन सा रोग होता है?",
            optionsEn = listOf("Rickets", "Beriberi", "Scurvy", "Night Blindness"),
            optionsHi = listOf("रिकेट्स (सूखा रोग)", "बेरीबेरी", "स्कर्वी", "रतौंधी"),
            correctOptionIndex = 2,
            explanationEn = "Deficiency of Vitamin C (Ascorbic acid) leads to scurvy, characterized by bleeding gums and slow healing.",
            explanationHi = "विटामिन सी (एस्कॉर्बिक एसिड) की कमी से स्कर्वी रोग होता है जिसमें मसूड़ों से खून आना और घाव देर से भरना शामिल है।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gs_7",
            subject = Subject.GS,
            topic = "Biology - Human Organs",
            topicHi = "जीव विज्ञान - अंग प्रणाली",
            questionEn = "Which organ is primarily responsible for filtering and purifying blood in the human body?",
            questionHi = "मानव शरीर में रक्त को छानकर शुद्ध करने का मुख्य कार्य कौन सा अंग करता है?",
            optionsEn = listOf("Liver", "Kidney (Nephrons)", "Lungs", "Heart"),
            optionsHi = listOf("यकृत (Liver)", "वृक्क (Kidney)", "फेफड़े", "हृदय"),
            correctOptionIndex = 1,
            explanationEn = "The kidneys filter metabolic wastes and extra fluid from blood through microscopic units called nephrons.",
            explanationHi = "वृक्क (किडनी) रक्त से अपशिष्ट पदार्थों और यूरिया को छानकर मूत्र के रूप में बाहर निकालता है।",
            sourceYear = "Agniveer CEE 2023"
        ),
        Question(
            id = "gs_8",
            subject = Subject.GS,
            topic = "Chemistry",
            topicHi = "रसायन विज्ञान",
            questionEn = "Which metal exists in liquid state at room temperature?",
            questionHi = "कमरे के सामान्य ताप पर कौन सी धातु द्रव (तरल) अवस्था में पाई जाती है?",
            optionsEn = listOf("Bromine", "Mercury (Hydrargyrum)", "Lead", "Aluminum"),
            optionsHi = listOf("ब्रोमीन", "पारा (Mercury)", "सीसा (Lead)", "एल्युमिनियम"),
            correctOptionIndex = 1,
            explanationEn = "Mercury (Hg) is a metal that is liquid at room temperature. Bromine is also liquid, but it is a non-metal.",
            explanationHi = "पारा (मरकरी) एकमात्र ऐसी धातु है जो कमरे के तापमान पर द्रव अवस्था में होती है। ब्रोमीन एक अधातु है।",
            sourceYear = "Army GD 2021"
        ),
        Question(
            id = "gs_9",
            subject = Subject.GS,
            topic = "Physics - Sound",
            topicHi = "भौतिकी - ध्वनि",
            questionEn = "Sound waves cannot travel through which of the following?",
            questionHi = "ध्वनि तरंगें निम्नलिखित में से किस माध्यम में गमन नहीं कर सकती हैं?",
            optionsEn = listOf("Water", "Steel", "Air", "Vacuum"),
            optionsHi = listOf("जल", "इस्पात (स्टील)", "वायु", "निर्वात (Vacuum)"),
            correctOptionIndex = 3,
            explanationEn = "Sound waves are mechanical waves and require a material medium (solid, liquid, or gas) to propagate. They cannot travel in a vacuum.",
            explanationHi = "ध्वनि यांत्रिक तरंग है जिसे संचरण के लिए माध्यम की आवश्यकता होती है। यह निर्वात में यात्रा नहीं कर सकती।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gs_10",
            subject = Subject.GS,
            topic = "Chemistry - Matter",
            topicHi = "रसायन विज्ञान - पदार्थ",
            questionEn = "What is the hardest naturally occurring substance known on Earth?",
            questionHi = "पृथ्वी पर ज्ञात सबसे कठोर प्राकृतिक पदार्थ कौन सा है?",
            optionsEn = listOf("Iron", "Diamond", "Tungsten", "Titanium"),
            optionsHi = listOf("लोहा", "हीरा (Diamond)", "टंगस्टन", "टाइटेनियम"),
            correctOptionIndex = 1,
            explanationEn = "Diamond, an allotrope of carbon with a rigid covalent lattice, is the hardest natural material.",
            explanationHi = "हीरा कार्बन का एक अपररूप है और प्रकृति में पाया जाने वाला सबसे कठोर ज्ञात पदार्थ है।",
            sourceYear = "Agniveer CEE 2023"
        ),
        Question(
            id = "gs_11",
            subject = Subject.GS,
            topic = "Biology - Hematology",
            topicHi = "जीव विज्ञान - रुधिर",
            questionEn = "The red color of human blood is due to the presence of:",
            questionHi = "मानव रक्त का लाल रंग किसकी उपस्थिति के कारण होता है?",
            optionsEn = listOf("Plasma", "Hemoglobin", "Chlorophyll", "Platelets"),
            optionsHi = listOf("प्लाज्मा", "हीमोग्लोबिन", "क्लोरोफिल", "प्लेटलेट्स"),
            correctOptionIndex = 1,
            explanationEn = "Hemoglobin is an iron-rich protein in red blood cells that binds oxygen and gives blood its red color.",
            explanationHi = "लाल रक्त कणिकाओं (RBC) में मौजूद लौह युक्त प्रोटीन 'हीमोग्लोबिन' के कारण रक्त का रंग लाल होता है।",
            sourceYear = "Army GD 2022"
        ),
        Question(
            id = "gs_12",
            subject = Subject.GS,
            topic = "Chemistry",
            topicHi = "रसायन विज्ञान",
            questionEn = "What is the chemical formula of Ozone gas?",
            questionHi = "ओजोन गैस का रासायनिक सूत्र क्या है?",
            optionsEn = listOf("O2", "O3", "O4", "CO"),
            optionsHi = listOf("O2", "O3", "O4", "CO"),
            correctOptionIndex = 1,
            explanationEn = "Ozone is an allotrope of oxygen made of three oxygen atoms, formula O3.",
            explanationHi = "ओजोन तीन ऑक्सीजन परमाणुओं से मिलकर बनती है, इसका रासायनिक सूत्र O3 होता है। यह पराबैंगनी किरणों से रक्षा करती है।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gs_13",
            subject = Subject.GS,
            topic = "Physics - Mechanics",
            topicHi = "भौतिकी - न्यूटन के नियम",
            questionEn = "A rocket propulsion system works on the principle of:",
            questionHi = "रॉकेट प्रक्षेपण किस सिद्धांत पर कार्य करता है?",
            optionsEn = listOf("Newton's First Law", "Newton's Third Law (Conservation of Momentum)", "Archimedes' Principle", "Coulomb's Law"),
            optionsHi = listOf("न्यूटन का प्रथम नियम", "न्यूटन का तीसरा नियम (संवेग संरक्षण)", "आर्किमिडीज का सिद्धांत", "कूलम्ब का नियम"),
            correctOptionIndex = 1,
            explanationEn = "Rocket propulsion is based on Newton's third law of motion: every action has an equal and opposite reaction, conserving linear momentum.",
            explanationHi = "रॉकेट प्रणोदन न्यूटन के गति के तीसरे नियम (प्रत्येक क्रिया के बराबर एवं विपरीत प्रतिक्रिया) और संवेग संरक्षण के नियम पर आधारित है।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "gs_14",
            subject = Subject.GS,
            topic = "Chemistry - Household",
            topicHi = "दैनिक जीवन में रसायन",
            questionEn = "What is the common chemical name of Baking Soda?",
            questionHi = "बेकिंग सोडा (खाने का सोडा) का रासायनिक नाम क्या है?",
            optionsEn = listOf("Sodium Carbonate", "Sodium Bicarbonate", "Calcium Hydroxide", "Sodium Chloride"),
            optionsHi = listOf("सोडियम कार्बोनेट", "सोडियम बाइकार्बोनेट (NaHCO3)", "कैल्शियम हाइड्रोक्साइड", "सोडियम क्लोराइड"),
            correctOptionIndex = 1,
            explanationEn = "Baking soda is Sodium Bicarbonate (NaHCO3). Washing soda is Sodium Carbonate (Na2CO3).",
            explanationHi = "बेकिंग सोडा का रासायनिक नाम सोडियम बाइकार्बोनेट (NaHCO3) है। धावन सोडा सोडियम कार्बोनेट होता है।",
            sourceYear = "Army GD Danapur 2023"
        ),
        Question(
            id = "gs_15",
            subject = Subject.GS,
            topic = "Physics - Energy",
            topicHi = "भौतिकी - ऊर्जा",
            questionEn = "The device that converts electrical energy into mechanical energy is called:",
            questionHi = "विद्युत ऊर्जा को यांत्रिक ऊर्जा में बदलने वाले उपकरण को क्या कहते हैं?",
            optionsEn = listOf("Electric Generator (Dynamo)", "Electric Motor", "Transformer", "Inverter"),
            optionsHi = listOf("विद्युत जनरेटर (डायनमो)", "विद्युत मोटर", "ट्रांसफॉर्मर", "इन्वर्टर"),
            correctOptionIndex = 1,
            explanationEn = "An electric motor converts electrical energy into mechanical energy. A generator does the reverse.",
            explanationHi = "विद्युत मोटर विद्युत ऊर्जा को यांत्रिक ऊर्जा में बदलती है, जबकि जनरेटर यांत्रिक ऊर्जा को विद्युत ऊर्जा में बदलता है।",
            sourceYear = "Agniveer CEE 2023"
        )
    )

    // --- MATHEMATICS (MATHS) QUESTIONS ---
    val mathsQuestions = listOf(
        Question(
            id = "math_1",
            subject = Subject.MATHS,
            topic = "Time & Work",
            topicHi = "समय एवं कार्य",
            questionEn = "If 15 men can complete a work in 20 days, in how many days can 25 men complete the same work?",
            questionHi = "यदि 15 व्यक्ति किसी कार्य को 20 दिनों में पूरा करते हैं, तो 25 व्यक्ति उसी कार्य को कितने दिनों में पूरा करेंगे?",
            optionsEn = listOf("10 days", "12 days", "14 days", "16 days"),
            optionsHi = listOf("10 दिन", "12 दिन", "14 दिन", "16 दिन"),
            correctOptionIndex = 1,
            explanationEn = "Formula: M1 × D1 = M2 × D2 => 15 × 20 = 25 × D2 => 300 = 25 × D2 => D2 = 300 / 25 = 12 days.",
            explanationHi = "सूत्र: M1 × D1 = M2 × D2 => 15 × 20 = 25 × D2 => D2 = 300 / 25 = 12 दिन।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "math_2",
            subject = Subject.MATHS,
            topic = "Speed, Time & Distance",
            topicHi = "चाल, समय एवं दूरी",
            questionEn = "A train 150 meters long is traveling at a speed of 54 km/h. How many seconds will it take to pass a telephone post?",
            questionHi = "150 मीटर लंबी एक रेलगाड़ी 54 किमी/घंटा की चाल से चल रही है। एक टेलीफोन के खंभे को पार करने में इसे कितना समय (सेकंड) लगेगा?",
            optionsEn = listOf("8 seconds", "10 seconds", "12 seconds", "15 seconds"),
            optionsHi = listOf("8 सेकंड", "10 सेकंड", "12 सेकंड", "15 सेकंड"),
            correctOptionIndex = 1,
            explanationEn = "Convert speed to m/s: 54 × (5/18) = 15 m/s. Time = Distance / Speed = 150 / 15 = 10 seconds.",
            explanationHi = "चाल को मी/से में बदलें: 54 × (5/18) = 15 मी/से। समय = दूरी / चाल = 150 / 15 = 10 सेकंड।",
            sourceYear = "Army GD 2023"
        ),
        Question(
            id = "math_3",
            subject = Subject.MATHS,
            topic = "Profit & Loss",
            topicHi = "लाभ एवं हानि",
            questionEn = "If the cost price of 10 pens is equal to the selling price of 8 pens, what is the profit percentage?",
            questionHi = "यदि 10 कलमों का क्रय मूल्य 8 कलमों के विक्रय मूल्य के बराबर है, तो लाभ प्रतिशत क्या होगा?",
            optionsEn = listOf("20%", "25%", "30%", "15%"),
            optionsHi = listOf("20%", "25%", "30%", "15%"),
            correctOptionIndex = 1,
            explanationEn = "Let CP of 1 pen = ₹1. CP of 8 pens = ₹8. SP of 8 pens = CP of 10 pens = ₹10. Profit = 10 - 8 = ₹2. Profit % = (2 / 8) × 100 = 25%.",
            explanationHi = "माना 1 कलम का CP = ₹1. 8 कलमों का SP = 10 कलमों का CP = ₹10. लाभ = ₹2. लाभ % = (2 / 8) × 100 = 25%.",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "math_4",
            subject = Subject.MATHS,
            topic = "Simple Interest",
            topicHi = "साधारण ब्याज",
            questionEn = "Calculate the simple interest on a principal of ₹5000 at 6% per annum for 3 years.",
            questionHi = "₹5000 की मूल राशि पर 6% वार्षिक दर से 3 वर्ष का साधारण ब्याज कितना होगा?",
            optionsEn = listOf("₹800", "₹900", "₹1000", "₹950"),
            optionsHi = listOf("₹800", "₹900", "₹1000", "₹950"),
            correctOptionIndex = 1,
            explanationEn = "Simple Interest = (P × R × T) / 100 = (5000 × 6 × 3) / 100 = 50 × 18 = ₹900.",
            explanationHi = "साधारण ब्याज = (मूलधन × दर × समय) / 100 = (5000 × 6 × 3) / 100 = ₹900।",
            sourceYear = "Army GD Danapur 2022"
        ),
        Question(
            id = "math_5",
            subject = Subject.MATHS,
            topic = "Averages",
            topicHi = "औसत",
            questionEn = "The average of five numbers is 20. If one number is excluded, the average becomes 18. What is the excluded number?",
            questionHi = "पाँच संख्याओं का औसत 20 है। यदि एक संख्या हटा दी जाए, तो शेष संख्याओं का औसत 18 हो जाता है। हटाई गई संख्या क्या है?",
            optionsEn = listOf("24", "26", "28", "30"),
            optionsHi = listOf("24", "26", "28", "30"),
            correctOptionIndex = 2,
            explanationEn = "Sum of 5 numbers = 5 × 20 = 100. Sum of remaining 4 numbers = 4 × 18 = 72. Excluded number = 100 - 72 = 28.",
            explanationHi = "5 संख्याओं का कुल योग = 5 × 20 = 100. 4 संख्याओं का कुल योग = 4 × 18 = 72. हटाई गई संख्या = 100 - 72 = 28।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "math_6",
            subject = Subject.MATHS,
            topic = "Mensuration - Circle",
            topicHi = "क्षेत्रमिति - वृत्त",
            questionEn = "What is the area of a circle with radius 7 cm? (Take π = 22/7)",
            questionHi = "7 सेमी त्रिज्या वाले वृत्त का क्षेत्रफल क्या होगा? (π = 22/7 लें)",
            optionsEn = listOf("144 cm²", "154 cm²", "164 cm²", "176 cm²"),
            optionsHi = listOf("144 सेमी²", "154 सेमी²", "164 सेमी²", "176 सेमी²"),
            correctOptionIndex = 1,
            explanationEn = "Area = π × r² = (22/7) × 7 × 7 = 22 × 7 = 154 cm².",
            explanationHi = "क्षेत्रफल = π × r² = (22/7) × 7 × 7 = 154 वर्ग सेमी।",
            sourceYear = "Agniveer CEE 2023"
        ),
        Question(
            id = "math_7",
            subject = Subject.MATHS,
            topic = "Percentages",
            topicHi = "प्रतिशत",
            questionEn = "Find the value of 15% of 600.",
            questionHi = "600 का 15% कितना होगा?",
            optionsEn = listOf("85", "90", "95", "100"),
            optionsHi = listOf("85", "90", "95", "100"),
            correctOptionIndex = 1,
            explanationEn = "15% of 600 = (15 / 100) × 600 = 15 × 6 = 90.",
            explanationHi = "600 का 15% = (15 / 100) × 600 = 90।",
            sourceYear = "Army GD 2021"
        ),
        Question(
            id = "math_8",
            subject = Subject.MATHS,
            topic = "Mensuration - Rectangle",
            topicHi = "क्षेत्रमिति - आयत",
            questionEn = "The perimeter of a rectangle is 48 cm and its length is 14 cm. Find its breadth.",
            questionHi = "एक आयत का परिमाप 48 सेमी है तथा इसकी लंबाई 14 सेमी है। इसकी चौड़ाई ज्ञात कीजिए।",
            optionsEn = listOf("8 cm", "10 cm", "12 cm", "14 cm"),
            optionsHi = listOf("8 सेमी", "10 सेमी", "12 सेमी", "14 सेमी"),
            correctOptionIndex = 1,
            explanationEn = "Perimeter = 2 × (Length + Breadth) => 48 = 2 × (14 + B) => 24 = 14 + B => B = 10 cm.",
            explanationHi = "परिमाप = 2 × (लंबाई + चौड़ाई) => 48 = 2 × (14 + चौड़ाई) => 24 = 14 + चौड़ाई => चौड़ाई = 10 सेमी।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "math_9",
            subject = Subject.MATHS,
            topic = "Ratio & Proportion",
            topicHi = "अनुपात एवं समानुपात",
            questionEn = "If A : B = 2 : 3 and B : C = 4 : 5, find the ratio A : B : C.",
            questionHi = "यदि A : B = 2 : 3 और B : C = 4 : 5 हो, तो A : B : C का मान क्या होगा?",
            optionsEn = listOf("8 : 12 : 15", "6 : 8 : 10", "4 : 6 : 9", "8 : 10 : 15"),
            optionsHi = listOf("8 : 12 : 15", "6 : 8 : 10", "4 : 6 : 9", "8 : 10 : 15"),
            correctOptionIndex = 0,
            explanationEn = "A = 2 × 4 = 8; B = 3 × 4 = 12; C = 3 × 5 = 15 => A : B : C = 8 : 12 : 15.",
            explanationHi = "A : B : C = (2×4) : (3×4) : (3×5) = 8 : 12 : 15।",
            sourceYear = "Army GD Lucknow 2022"
        ),
        Question(
            id = "math_10",
            subject = Subject.MATHS,
            topic = "Algebra",
            topicHi = "बीजगणित",
            questionEn = "Solve for x: 3x + 12 = 30.",
            questionHi = "हल कीजिए: 3x + 12 = 30 में x का मान क्या है?",
            optionsEn = listOf("4", "5", "6", "8"),
            optionsHi = listOf("4", "5", "6", "8"),
            correctOptionIndex = 2,
            explanationEn = "3x = 30 - 12 => 3x = 18 => x = 18 / 3 = 6.",
            explanationHi = "3x = 30 - 12 => 3x = 18 => x = 18 / 3 = 6।",
            sourceYear = "Agniveer CEE 2023"
        ),
        Question(
            id = "math_11",
            subject = Subject.MATHS,
            topic = "HCF & LCM",
            topicHi = "म.स.प. एवं ल.स.प.",
            questionEn = "Find the Highest Common Factor (HCF) of 24 and 36.",
            questionHi = "24 और 36 का महत्तम समापवर्तक (HCF) ज्ञात कीजिए।",
            optionsEn = listOf("6", "8", "12", "18"),
            optionsHi = listOf("6", "8", "12", "18"),
            correctOptionIndex = 2,
            explanationEn = "Factors of 24 = 1, 2, 3, 4, 6, 8, 12, 24. Factors of 36 = 1, 2, 3, 4, 6, 9, 12, 18, 36. Greatest common divisor is 12.",
            explanationHi = "24 = 12 × 2 तथा 36 = 12 × 3. सबसे बड़ा उभयनिष्ठ गुणनखंड 12 है।",
            sourceYear = "Army GD 2021"
        ),
        Question(
            id = "math_12",
            subject = Subject.MATHS,
            topic = "Geometry",
            topicHi = "ज्यामिति",
            questionEn = "What is the sum of interior angles of any triangle?",
            questionHi = "किसी भी त्रिभुज के तीनों अंतः कोणों का योग कितना होता है?",
            optionsEn = listOf("90°", "180°", "270°", "360°"),
            optionsHi = listOf("90°", "180°", "270°", "360°"),
            correctOptionIndex = 1,
            explanationEn = "The sum of all three interior angles in any triangle is always 180 degrees.",
            explanationHi = "त्रिभुज के तीनों आंतरिक कोणों का योग सदैव 180° होता है।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "math_13",
            subject = Subject.MATHS,
            topic = "Squares & Cubes",
            topicHi = "वर्ग एवं घन",
            questionEn = "What is the cube of 8?",
            questionHi = "8 का घन (Cube) क्या होगा?",
            optionsEn = listOf("64", "256", "512", "1024"),
            optionsHi = listOf("64", "256", "512", "1024"),
            correctOptionIndex = 2,
            explanationEn = "8³ = 8 × 8 × 8 = 64 × 8 = 512.",
            explanationHi = "8³ = 8 × 8 × 8 = 512।",
            sourceYear = "Army GD Danapur 2023"
        ),
        Question(
            id = "math_14",
            subject = Subject.MATHS,
            topic = "Square Roots",
            topicHi = "वर्गमूल",
            questionEn = "Find the square root of 1764 (√1764).",
            questionHi = "1764 का वर्गमूल (√1764) क्या होगा?",
            optionsEn = listOf("38", "42", "44", "46"),
            optionsHi = listOf("38", "42", "44", "46"),
            correctOptionIndex = 1,
            explanationEn = "42 × 42 = 1764. Thus √1764 = 42.",
            explanationHi = "42 × 42 = 1764. अतः √1764 = 42।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "math_15",
            subject = Subject.MATHS,
            topic = "Speed & Distance",
            topicHi = "चाल एवं दूरी",
            questionEn = "If a vehicle covers 180 km in 3 hours, what is its speed in m/s?",
            questionHi = "यदि कोई वाहन 3 घंटे में 180 किमी की दूरी तय करता है, तो उसकी चाल मीटर/सेकंड में क्या होगी?",
            optionsEn = listOf("15 m/s", "16.67 m/s", "20 m/s", "25 m/s"),
            optionsHi = listOf("15 मी/से", "16.67 मी/से", "20 मी/से", "25 मी/से"),
            correctOptionIndex = 1,
            explanationEn = "Speed = 180 / 3 = 60 km/h. In m/s: 60 × (5/18) = 300 / 18 = 16.67 m/s.",
            explanationHi = "चाल = 180 / 3 = 60 किमी/घंटा। मी/से में = 60 × (5/18) = 50 / 3 ≈ 16.67 मी/से।",
            sourceYear = "Agniveer CEE 2023"
        )
    )

    // --- LOGICAL REASONING QUESTIONS (5 in CEE) ---
    val reasoningQuestions = listOf(
        Question(
            id = "reas_1",
            subject = Subject.REASONING,
            topic = "Number Series",
            topicHi = "संख्या श्रृंखला",
            questionEn = "Complete the series: 2, 6, 12, 20, 30, ?",
            questionHi = "श्रृंखला को पूरा करें: 2, 6, 12, 20, 30, ?",
            optionsEn = listOf("36", "40", "42", "44"),
            optionsHi = listOf("36", "40", "42", "44"),
            correctOptionIndex = 2,
            explanationEn = "Difference between consecutive terms: +4, +6, +8, +10, next is +12 => 30 + 12 = 42. (Or n² + n: 1²+1=2, 2²+2=6, 3²+3=12, 4²+4=20, 5²+5=30, 6²+6=42).",
            explanationHi = "अंतर देखें: +4, +6, +8, +10, अगला अंतर +12 होगा => 30 + 12 = 42।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "reas_2",
            subject = Subject.REASONING,
            topic = "Coding-Decoding",
            topicHi = "कोडिंग-डिकोडिंग",
            questionEn = "In a code language, if 'ARMY' is written as 'BSNZ', how will 'BRAVE' be written in the same code?",
            questionHi = "यदि किसी कूट भाषा में 'ARMY' को 'BSNZ' लिखा जाता है, तो उसी कूट में 'BRAVE' को क्या लिखा जाएगा?",
            optionsEn = listOf("CSBWF", "CSBVF", "DQBWF", "CRBUF"),
            optionsHi = listOf("CSBWF", "CSBVF", "DQBWF", "CRBUF"),
            correctOptionIndex = 0,
            explanationEn = "Each letter is shifted by +1: B(+1)=C, R(+1)=S, A(+1)=B, V(+1)=W, E(+1)=F => CSBWF.",
            explanationHi = "प्रत्येक अक्षर में +1 की वृद्धि हो रही है: B->C, R->S, A->B, V->W, E->F => CSBWF।",
            sourceYear = "Army GD 2023"
        ),
        Question(
            id = "reas_3",
            subject = Subject.REASONING,
            topic = "Classification (Odd One Out)",
            topicHi = "वर्गीकरण (विषम छांटना)",
            questionEn = "Find the odd one out from the given options:",
            questionHi = "दिए गए विकल्पों में से विषम (अलग) का चयन कीजिए:",
            optionsEn = listOf("Dog", "Cat", "Lion", "Chair"),
            optionsHi = listOf("कुत्ता", "बिल्ली", "शेर", "कुर्सी"),
            correctOptionIndex = 3,
            explanationEn = "Chair is a non-living object, while Dog, Cat, and Lion are living animals.",
            explanationHi = "कुर्सी एक निर्जीव वस्तु है, जबकि कुत्ता, बिल्ली और शेर सजीव प्राणी (पशु) हैं।",
            sourceYear = "Agniveer CEE 2024"
        ),
        Question(
            id = "reas_4",
            subject = Subject.REASONING,
            topic = "Direction Sense",
            topicHi = "दिशा ज्ञान",
            questionEn = "A recruit marches 5 km North, turns right and marches 4 km, then turns right again and marches 5 km. In which direction is he from the starting point?",
            questionHi = "एक रंगरूट उत्तर की ओर 5 किमी मार्च करता है, फिर दाएं मुड़कर 4 किमी चलता है, और फिर दाएं मुड़कर 5 किमी चलता है। अब वह प्रारंभिक बिंदु से किस दिशा में है?",
            optionsEn = listOf("North", "South", "East", "West"),
            optionsHi = listOf("उत्तर", "दक्षिण", "पूर्व (East)", "पश्चिम"),
            correctOptionIndex = 2,
            explanationEn = "The recruit walked 5km North, 4km East, and 5km South. The North and South cancel out, leaving him 4km East of the starting point.",
            explanationHi = "रंगरूट 5 किमी उत्तर गया, फिर 4 किमी पूर्व, फिर 5 किमी दक्षिण। अतः वह प्रारंभिक बिंदु से 4 किमी पूर्व (East) दिशा में है।",
            sourceYear = "Army GD Danapur 2022"
        ),
        Question(
            id = "reas_5",
            subject = Subject.REASONING,
            topic = "Blood Relations",
            topicHi = "रक्त संबंध",
            questionEn = "Pointing towards a photo, Amit said, 'He is the only son of my father's father.' How is the person related to Amit?",
            questionHi = "एक तस्वीर की ओर इशारा करते हुए अमित ने कहा, 'वह मेरे पिता के पिता का इकलौता पुत्र है।' वह व्यक्ति अमित का क्या है?",
            optionsEn = listOf("Uncle", "Father", "Brother", "Grandfather"),
            optionsHi = listOf("चाचा", "पिता (Father)", "भाई", "दादा"),
            correctOptionIndex = 1,
            explanationEn = "Father's father is grandfather. The only son of grandfather is Amit's father.",
            explanationHi = "पिता के पिता = दादा। दादा का इकलौता पुत्र = स्वयं अमित का पिता।",
            sourceYear = "Agniveer CEE 2024"
        )
    )

    // Full 50 Question Standard CEE set (15 GK + 15 GS + 15 Maths + 5 Reasoning)
    val standardCee50Questions: List<Question> by lazy {
        gkQuestions + gsQuestions + mathsQuestions + reasoningQuestions
    }

    // Alternative variants for previous years papers to provide realistic variety
    val pyq2023Questions: List<Question> by lazy {
        standardCee50Questions.shuffled().take(50).ifEmpty { standardCee50Questions }
    }

    val pyq2022Questions: List<Question> by lazy {
        // Reordered by subject
        gkQuestions.reversed() + gsQuestions.reversed() + mathsQuestions.reversed() + reasoningQuestions.reversed()
    }

    val allExamPapers: List<ExamPaper> by lazy {
        listOf(
            ExamPaper(
                id = "paper_daily_mock",
                title = "Daily Agniveer GD Mock Test",
                titleHi = "दैनिक अग्निवीर जीडी मॉक टेस्ट",
                subtitle = "Today's Live Test • 50 Qs • 60 Mins",
                type = PaperType.DAILY_MOCK,
                totalQuestions = 50,
                durationMinutes = 60,
                totalMarks = 100f,
                passingMarks = 35f,
                targetYear = "Daily Live CEE",
                questions = standardCee50Questions
            ),
            ExamPaper(
                id = "paper_pyq_2024",
                title = "Agniveer CEE 2024 Official Shift 1",
                titleHi = "अग्निवीर CEE 2024 ऑफिशियल शिफ्ट-1",
                subtitle = "Official CEE Exam Pattern • 100 Marks",
                type = PaperType.PREVIOUS_YEAR_PAPER,
                totalQuestions = 50,
                durationMinutes = 60,
                totalMarks = 100f,
                passingMarks = 35f,
                targetYear = "2024 CEE",
                questions = standardCee50Questions
            ),
            ExamPaper(
                id = "paper_pyq_2023",
                title = "Army GD CEE 2023 All India Paper",
                titleHi = "आर्मी जीडी CEE 2023 ऑल इंडिया पेपर",
                subtitle = "Combined Entrance Exam Paper with Solutions",
                type = PaperType.PREVIOUS_YEAR_PAPER,
                totalQuestions = 50,
                durationMinutes = 60,
                totalMarks = 100f,
                passingMarks = 35f,
                targetYear = "2023 CEE",
                questions = pyq2023Questions
            ),
            ExamPaper(
                id = "paper_pyq_2022",
                title = "Army Soldier GD 2022 Danapur/Ambala",
                titleHi = "आर्मी सोल्जर जीडी 2022 दानापुर/अंबाला",
                subtitle = "ARO Real Original Question Paper",
                type = PaperType.PREVIOUS_YEAR_PAPER,
                totalQuestions = 50,
                durationMinutes = 60,
                totalMarks = 100f,
                passingMarks = 35f,
                targetYear = "2022 ARO",
                questions = pyq2022Questions
            ),
            ExamPaper(
                id = "paper_full_mock_1",
                title = "All India Agniveer GD Super Mock #1",
                titleHi = "ऑल इंडिया अग्निवीर जीडी सुपर मॉक #1",
                subtitle = "High Probability Questions for Upcoming CEE",
                type = PaperType.FULL_MOCK,
                totalQuestions = 50,
                durationMinutes = 60,
                totalMarks = 100f,
                passingMarks = 35f,
                targetYear = "2024-2025 CEE",
                questions = standardCee50Questions
            ),
            ExamPaper(
                id = "paper_sec_gk",
                title = "General Knowledge Speed Drill (GK)",
                titleHi = "सामान्य ज्ञान स्पीड टेस्ट (GK)",
                subtitle = "15 Questions • 15 Mins • 30 Marks",
                type = PaperType.SECTIONAL,
                totalQuestions = 15,
                durationMinutes = 15,
                totalMarks = 30f,
                passingMarks = 11f,
                targetYear = "Sectional",
                questions = gkQuestions
            ),
            ExamPaper(
                id = "paper_sec_gs",
                title = "General Science Rapid Booster (GS)",
                titleHi = "सामान्य विज्ञान रैपिड बूस्टर (GS)",
                subtitle = "15 Questions • 15 Mins • 30 Marks",
                type = PaperType.SECTIONAL,
                totalQuestions = 15,
                durationMinutes = 15,
                totalMarks = 30f,
                passingMarks = 11f,
                targetYear = "Sectional",
                questions = gsQuestions
            ),
            ExamPaper(
                id = "paper_sec_maths",
                title = "Mathematics Formula & Practice Drill",
                titleHi = "गणित सूत्र एवं अभ्यास टेस्ट (Maths)",
                subtitle = "15 Questions • 20 Mins • 30 Marks",
                type = PaperType.SECTIONAL,
                totalQuestions = 15,
                durationMinutes = 20,
                totalMarks = 30f,
                passingMarks = 11f,
                targetYear = "Sectional",
                questions = mathsQuestions
            ),
            ExamPaper(
                id = "paper_sec_reasoning",
                title = "Logical Reasoning 5/5 Speed Drill",
                titleHi = "तर्कशक्ति 5/5 स्पीड ड्रिल",
                subtitle = "5 Questions • 8 Mins • 10 Marks",
                type = PaperType.SECTIONAL,
                totalQuestions = 5,
                durationMinutes = 8,
                totalMarks = 10f,
                passingMarks = 4f,
                targetYear = "Sectional",
                questions = reasoningQuestions
            )
        )
    }

    // Defense facts & Quick revision cards for candidates
    data class DefenseFact(
        val titleEn: String,
        val titleHi: String,
        val detailsEn: String,
        val detailsHi: String,
        val category: String
    )

    val defenseRevisionFacts = listOf(
        DefenseFact(
            titleEn = "Indian Army 7 Commands & Headquarters",
            titleHi = "भारतीय सेना की 7 कमानें और मुख्यालय",
            detailsEn = "1. Northern Command: Udhampur\n2. Western Command: Chandimandir\n3. Eastern Command: Kolkata\n4. Southern Command: Pune\n5. Central Command: Lucknow\n6. South Western Command: Jaipur\n7. Army Training Command (ARTRAC): Shimla",
            detailsHi = "1. उत्तरी कमान: उधमपुर\n2. पश्चिमी कमान: चंडीमंदिर\n3. पूर्वी कमान: कोलकाता\n4. दक्षिणी कमान: पुणे\n5. मध्य कमान: लखनऊ\n6. दक्षिण-पश्चिमी कमान: जयपुर\n7. आर्मी ट्रेनिंग कमान (ARTRAC): शिमला",
            category = "Commands"
        ),
        DefenseFact(
            titleEn = "Army Ranks Hierarchy (Junior Commissioned)",
            titleHi = "सेना के पद (JCO एवं NCO)",
            detailsEn = "Sepoy (Agniveer) -> Lance Naik -> Naik -> Havildar -> Naib Subedar -> Subedar -> Subedar Major (Highest JCO Rank).",
            detailsHi = "सिपाही (अग्निवीर) -> लांस नायक -> नायक -> हवलदार -> नायब सूबेदार -> सूबेदार -> सूबेदार मेजर (सर्वोच्च जेसीओ पद)।",
            category = "Ranks"
        ),
        DefenseFact(
            titleEn = "Wartime Gallantry Awards Order",
            titleHi = "युद्धकालीन वीरता पुरस्कारों का क्रम",
            detailsEn = "1. Param Vir Chakra (PVC) - Highest Wartime Gallantry\n2. Maha Vir Chakra (MVC)\n3. Vir Chakra (VrC)",
            detailsHi = "1. परमवीर चक्र (सर्वोच्च वीरता पुरस्कार)\n2. महावीर चक्र\n3. वीर चक्र",
            category = "Awards"
        ),
        DefenseFact(
            titleEn = "Peacetime Gallantry Awards Order",
            titleHi = "शांतिकाल के वीरता पुरस्कार",
            detailsEn = "1. Ashoka Chakra - Highest Peacetime Gallantry\n2. Kirti Chakra\n3. Shaurya Chakra",
            detailsHi = "1. अशोक चक्र (शांतिकाल का सर्वोच्च वीरता पदक)\n2. कीर्ति चक्र\n3. शौर्य चक्र",
            category = "Awards"
        ),
        DefenseFact(
            titleEn = "India's Indigenous Missiles (IGMDP)",
            titleHi = "भारत की प्रमुख स्वदेशी मिसाइलें (PATNA)",
            detailsEn = "P - Prithvi (Surface-to-Surface)\nA - Agni (Intercontinental Ballistic Missile)\nT - Trishul (Short-range Surface-to-Air)\nN - Nag (Anti-tank Guided Missile)\nA - Akash (Medium-range Surface-to-Air)",
            detailsHi = "P - पृथ्वी (सतह से सतह)\nA - अग्नि (बैलिस्टिक मिसाइल)\nT - त्रिशूल (कम दूरी की सतह से हवा)\nN - नाग (एंटी-टैंक मिसाइल)\nA - आकाश (मध्यम दूरी सतह से हवा)",
            category = "Missiles"
        )
    )
}
