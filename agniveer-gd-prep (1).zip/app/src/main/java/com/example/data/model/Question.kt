package com.example.data.model

data class Question(
    val id: String,
    val subject: Subject,
    val topic: String,
    val topicHi: String,
    val questionEn: String,
    val questionHi: String,
    val optionsEn: List<String>,
    val optionsHi: List<String>,
    val correctOptionIndex: Int,
    val explanationEn: String,
    val explanationHi: String,
    val sourceYear: String = "Agniveer GD CEE"
)
