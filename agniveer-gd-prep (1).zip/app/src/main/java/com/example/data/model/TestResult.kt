package com.example.data.model

data class SubjectScoreSummary(
    val totalQuestions: Int,
    val attempted: Int,
    val correct: Int,
    val wrong: Int,
    val score: Float,
    val maxScore: Float
)

data class TestResult(
    val attemptId: Long = 0,
    val paperId: String,
    val paperTitle: String,
    val timestamp: Long,
    val timeSpentSeconds: Int,
    val score: Float,
    val maxScore: Float,
    val isPassed: Boolean,
    val totalQuestions: Int,
    val attemptedCount: Int,
    val correctCount: Int,
    val wrongCount: Int,
    val unansweredCount: Int,
    val accuracyPercentage: Float,
    val userAnswers: Map<String, Int>, // questionId -> selectedOptionIndex
    val subjectBreakdown: Map<Subject, SubjectScoreSummary>
)
