package com.example.data.model

data class RunningGrade(
    val group: String,
    val timeLimit: String,
    val marks: Int,
    val description: String
)

data class PullUpGrade(
    val pullUpsCount: Int,
    val marks: Int,
    val status: String
)

data class RegionStandard(
    val regionName: String,
    val statesIncluded: String,
    val minHeightCm: Int,
    val minChestCm: String,
    val minWeightKg: Int
)

object AgniveerPhysicalStandards {
    val runningGrades = listOf(
        RunningGrade(
            group = "Group I (First Batch)",
            timeLimit = "Up to 5 Min 30 Sec (<= 5:30)",
            marks = 60,
            description = "Full 60 marks awarded. Excellent aerobic performance."
        ),
        RunningGrade(
            group = "Group II (Second Batch)",
            timeLimit = "5 Min 31 Sec to 5 Min 45 Sec (5:31 - 5:45)",
            marks = 48,
            description = "48 marks awarded. Satisfactory timing."
        ),
        RunningGrade(
            group = "Fail / Not Qualified",
            timeLimit = "Over 5 Min 45 Sec (> 5:45)",
            marks = 0,
            description = "Disqualified in Rally ground. Candidate must try in next rally."
        )
    )

    val pullUpGrades = listOf(
        PullUpGrade(10, 40, "Maximum Marks"),
        PullUpGrade(9, 33, "Good"),
        PullUpGrade(8, 27, "Average"),
        PullUpGrade(7, 21, "Passing"),
        PullUpGrade(6, 16, "Minimum Qualifying"),
        PullUpGrade(5, 0, "Failed (< 6 pull-ups)")
    )

    val otherTests = listOf(
        Pair("9 Feet Ditch Jump", "Need to Clear / Qualifying Nature (No marks awarded, compulsory to qualify)"),
        Pair("Zig-Zag Balance", "Need to Qualify / Candidate must cross without stepping off")
    )

    val regionalStandards = listOf(
        RegionStandard(
            regionName = "Western Himalayan Region",
            statesIncluded = "J&K, Himachal Pradesh, Punjab Hills, Garhwal & Kumaon (Uttarakhand)",
            minHeightCm = 163,
            minChestCm = "77 cm (+5 cm expansion)",
            minWeightKg = 48
        ),
        RegionStandard(
            regionName = "Eastern Himalayan Region",
            statesIncluded = "Sikkim, Nagaland, Arunachal, Manipur, Tripura, Mizoram, Meghalaya, Assam",
            minHeightCm = 160,
            minChestCm = "77 cm (+5 cm expansion)",
            minWeightKg = 48
        ),
        RegionStandard(
            regionName = "Western Plains Region",
            statesIncluded = "Punjab, Haryana, Chandigarh, Delhi, Rajasthan, Western UP (Meerut & Agra)",
            minHeightCm = 170,
            minChestCm = "77 cm (+5 cm expansion)",
            minWeightKg = 50
        ),
        RegionStandard(
            regionName = "Eastern Plains Region",
            statesIncluded = "Eastern UP, Bihar, West Bengal, Jharkhand, Odisha",
            minHeightCm = 169,
            minChestCm = "77 cm (+5 cm expansion)",
            minWeightKg = 50
        ),
        RegionStandard(
            regionName = "Central Region",
            statesIncluded = "Madhya Pradesh, Chhattisgarh, Gujarat, Maharashtra, Goa",
            minHeightCm = 168,
            minChestCm = "77 cm (+5 cm expansion)",
            minWeightKg = 50
        ),
        RegionStandard(
            regionName = "Southern Region",
            statesIncluded = "Andhra Pradesh, Telangana, Karnataka, Tamil Nadu, Kerala, Pondicherry",
            minHeightCm = 166,
            minChestCm = "77 cm (+5 cm expansion)",
            minWeightKg = 50
        )
    )

    fun calculatePhysicalScore(runSeconds: Int, pullUps: Int): Pair<Int, String> {
        val runMarks = when {
            runSeconds <= 330 -> 60
            runSeconds <= 345 -> 48
            else -> 0
        }
        val pullUpMarks = when {
            pullUps >= 10 -> 40
            pullUps == 9 -> 33
            pullUps == 8 -> 27
            pullUps == 7 -> 21
            pullUps == 6 -> 16
            else -> 0
        }

        val total = runMarks + pullUpMarks
        val remarks = when {
            runMarks == 0 && pullUpMarks == 0 -> "Failed in both Run & Beam. Dedicate 60 days to stamina!"
            runMarks == 0 -> "Disqualified in 1.6 KM run (exceeded 5:45 min limit)."
            pullUpMarks == 0 -> "Failed in Beam pull-ups (< 6 minimum required)."
            total == 100 -> "EXCELLENT! 100/100 Physical Marks (Group 1 + 10 Pull-ups). High Merit probability!"
            total >= 80 -> "GREAT! Total Physical Marks: $total/100. Strong merit score."
            total >= 64 -> "QUALIFIED! Total Physical Marks: $total/100. Focus on scoring 85+ in CEE to ensure merit."
            else -> "MINIMUM QUALIFY: $total/100. Work hard on CEE written exam."
        }
        return Pair(total, remarks)
    }
}
