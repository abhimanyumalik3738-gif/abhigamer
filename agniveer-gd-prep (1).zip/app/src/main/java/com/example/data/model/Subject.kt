package com.example.data.model

enum class Subject(
    val titleEn: String,
    val titleHi: String,
    val totalQuestionsInCEE: Int,
    val totalMarksInCEE: Int,
    val iconName: String
) {
    GK(
        titleEn = "General Knowledge",
        titleHi = "सामान्य ज्ञान",
        totalQuestionsInCEE = 15,
        totalMarksInCEE = 30,
        iconName = "menu_book"
    ),
    GS(
        titleEn = "General Science",
        titleHi = "सामान्य विज्ञान",
        totalQuestionsInCEE = 15,
        totalMarksInCEE = 30,
        iconName = "science"
    ),
    MATHS(
        titleEn = "Mathematics",
        titleHi = "गणित",
        totalQuestionsInCEE = 15,
        totalMarksInCEE = 30,
        iconName = "calculate"
    ),
    REASONING(
        titleEn = "Logical Reasoning",
        titleHi = "तर्कशक्ति",
        totalQuestionsInCEE = 5,
        totalMarksInCEE = 10,
        iconName = "psychology"
    )
}
