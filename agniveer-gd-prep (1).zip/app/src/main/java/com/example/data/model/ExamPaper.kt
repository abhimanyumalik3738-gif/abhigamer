package com.example.data.model

enum class PaperType {
    DAILY_MOCK,
    FULL_MOCK,
    PREVIOUS_YEAR_PAPER,
    SECTIONAL
}

data class ExamPaper(
    val id: String,
    val title: String,
    val titleHi: String,
    val subtitle: String,
    val type: PaperType,
    val totalQuestions: Int,
    val durationMinutes: Int,
    val totalMarks: Float,
    val passingMarks: Float,
    val markPerCorrect: Float = 2.0f,
    val negativeMarkPerWrong: Float = 0.5f,
    val targetYear: String,
    val questions: List<Question>
)
