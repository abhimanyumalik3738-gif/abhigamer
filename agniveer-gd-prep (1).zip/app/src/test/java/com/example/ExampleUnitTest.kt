package com.example

import com.example.data.model.AgniveerPhysicalStandards
import com.example.data.model.PaperType
import com.example.data.model.Subject
import com.example.data.repository.MockData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testPhysicalScoreCalculation_groupOneAndTenPullUps() {
        // 5 mins 20 secs = 320 seconds, 10 pull-ups -> 60 + 40 = 100
        val (score, remarks) = AgniveerPhysicalStandards.calculatePhysicalScore(320, 10)
        assertEquals(100, score)
        assertTrue(remarks.contains("100/100"))
    }

    @Test
    fun testPhysicalScoreCalculation_groupTwoAndEightPullUps() {
        // 5 mins 40 secs = 340 seconds (Group 2 = 48 marks), 8 pull-ups = 27 marks -> 48 + 27 = 75
        val (score, remarks) = AgniveerPhysicalStandards.calculatePhysicalScore(340, 8)
        assertEquals(75, score)
        assertTrue(remarks.contains("75/100"))
    }

    @Test
    fun testPhysicalScoreCalculation_disqualifiedOverTime() {
        // 5 mins 50 secs = 350 seconds (> 5:45 -> run failed)
        val (score, remarks) = AgniveerPhysicalStandards.calculatePhysicalScore(350, 10)
        assertEquals(40, score)
        assertTrue(remarks.contains("Disqualified in 1.6 KM run"))
    }

    @Test
    fun testStandardCeePapers_haveFiftyQuestions() {
        val dailyPaper = MockData.allExamPapers.find { it.type == PaperType.DAILY_MOCK }
        assertNotNull(dailyPaper)
        assertEquals(50, dailyPaper!!.totalQuestions)
        assertEquals(100f, dailyPaper.totalMarks, 0.01f)
        assertEquals(35f, dailyPaper.passingMarks, 0.01f)
    }

    @Test
    fun testBilingualQuestions_haveEnglishAndHindiText() {
        val allQuestions = MockData.standardCee50Questions
        assertTrue(allQuestions.isNotEmpty())
        for (q in allQuestions) {
            assertTrue("Question EN should not be blank: ${q.id}", q.questionEn.isNotBlank())
            assertTrue("Question HI should not be blank: ${q.id}", q.questionHi.isNotBlank())
            assertEquals("Options count should be 4: ${q.id}", 4, q.optionsEn.size)
            assertEquals("Options HI count should be 4: ${q.id}", 4, q.optionsHi.size)
            assertTrue("Correct option index must be in 0..3: ${q.id}", q.correctOptionIndex in 0..3)
            assertTrue("Explanation EN should not be blank: ${q.id}", q.explanationEn.isNotBlank())
            assertTrue("Explanation HI should not be blank: ${q.id}", q.explanationHi.isNotBlank())
        }
    }

    @Test
    fun testSubjectDistributionInCee() {
        val allQuestions = MockData.standardCee50Questions
        assertEquals(15, allQuestions.count { it.subject == Subject.GK })
        assertEquals(15, allQuestions.count { it.subject == Subject.GS })
        assertEquals(15, allQuestions.count { it.subject == Subject.MATHS })
        assertEquals(5, allQuestions.count { it.subject == Subject.REASONING })
    }
}
